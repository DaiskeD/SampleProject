-------------------------------------------------------------------------------
--
-- VSEInstallSchema.sql : adds the schema to the DB
--
-- Copyright (c) 2010 McAfee, Inc.  All Rights Reserved.
--
-------------------------------------------------------------------------------
if  exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[VSECustomProps]') AND type in (N'U'))
  DROP TABLE [dbo].[VSECustomProps]
GO

CREATE TABLE [dbo].[VSECustomProps]
(
	[AutoID]                        [int] NOT NULL IDENTITY (1,1),
	[ParentID]                      [int] NOT NULL,             -- Required for custom properties

	[OASArtemisLevel]             [nvarchar] (3000) NULL,
	[EmailArtemisLevel]           [nvarchar] (3000) NULL,
	[ODSArtemisLevel]             [nvarchar] (3000) NULL,
    [MachineType]                 [nvarchar] (3000) NULL,
    [VSEHotfixes]                 [nvarchar] (3000) NULL,
    [OASEnabled]                  [nvarchar] (3000) NULL,
    [APEnabled]                  [nvarchar] (3000) NULL,
    [EnhancedSPEnabled]                  [nvarchar] (3000) NULL
	CONSTRAINT [PK_VSECustomProps] PRIMARY KEY CLUSTERED
	(
		[AutoID] ASC
	)ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[VSECustomProps] ADD
	CONSTRAINT [FK_VSECustomProps_EPOProductProperties] FOREIGN KEY (
		[ParentID]
	) REFERENCES [dbo].[EPOProductProperties] (
		[AutoID]
	) ON DELETE CASCADE ON UPDATE NO ACTION
GO

IF EXISTS (SELECT * from sys.indexes where object_id = OBJECT_ID('VSECustomProps') and name = 'IX_VSECustomProps_ParentID')
  DROP INDEX [IX_VSECustomProps_ParentID] ON [dbo].[VSECustomProps];
GO

CREATE INDEX [IX_VSECustomProps_ParentID] ON [dbo].[VSECustomProps] ([ParentID] ASC);
GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[VSEadditionalpropsView]'))
     DROP VIEW [dbo].[VSEadditionalpropsView]
 GO

 IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[VSECustomPropsView]'))
     DROP VIEW [dbo].[VSECustomPropsView]
 GO

CREATE VIEW [dbo].[VSECustomPropsView] AS
     SELECT ProdProps.ParentID as LeafNodeID, VSECS.AutoID, VSECS.ParentID,
    CASE WHEN VSECS.OASArtemisLevel IS NOT NULL THEN VSECS.OASArtemisLevel ELSE 'Unknown' END AS OASArtemisLevel,
    CASE WHEN VSECS.EmailArtemisLevel IS NOT NULL THEN VSECS.EmailArtemisLevel ELSE 'Unknown' END AS EmailArtemisLevel,
    CASE WHEN VSECS.ODSArtemisLevel IS NOT NULL THEN VSECS.ODSArtemisLevel ELSE 'Unknown' END AS ODSArtemisLevel,
    CASE WHEN VSECS.MachineType IS NOT NULL THEN VSECS.MachineType ELSE 'Unknown' END AS MachineType,
    CASE WHEN VSECS.VSEHotfixes IS NOT NULL THEN VSECS.VSEHotfixes ELSE 'None' END AS VSEHotfixes,
    CASE WHEN VSECS.OASEnabled IS NOT NULL THEN VSECS.OASEnabled ELSE 'Unknown' END AS OASEnabled,
    CASE WHEN VSECS.APEnabled IS NOT NULL THEN VSECS.APEnabled ELSE 'Unknown' END AS APEnabled,
    CASE WHEN VSECS.EnhancedSPEnabled IS NOT NULL THEN VSECS.EnhancedSPEnabled ELSE 'Unknown' END AS EnhancedSPEnabled
     FROM [dbo].[EPOProductProperties] AS ProdProps
     JOIN [dbo].[VSECustomProps] as VSECS ON ProdProps.AutoID=VSECS.ParentID
     JOIN [EPOLeafNode] ON [EPOLeafNode].[AutoID] = ProdProps.ParentID
 GO

IF EXISTS(SELECT name from sysobjects where name LIKE 'VSE_CopyProperties' and type = 'P')
BEGIN
	DROP PROCEDURE [VSE_CopyProperties]
END
GO

CREATE PROCEDURE [dbo].[VSE_CopyProperties]
(@rowsfound int OUTPUT)

AS
BEGIN

  DECLARE @missingItems table ([ParentId] int);

  INSERT INTO @missingItems ([ParentID])
	  SELECT [AutoId] from EPOProductProperties where ProductCode LIKE 'VIRUSCAN%' and AutoID NOT IN ( SELECT ParentID From VSECustomProps )

  SET @rowsfound = @@ROWCOUNT

  if(@rowsfound<>0)
  BEGIN
    INSERT INTO [VSECustomProps]
              ([ParentID]
              ,[OASArtemisLevel]
              ,[EmailArtemisLevel]
              ,[ODSArtemisLevel]
              ,[MachineType]
              ,[VSEHotfixes]
              ,[OASEnabled]
              ,[APEnabled]
              ,[EnhancedSPEnabled])
    SELECT
     Temptable.ParentID as ParentID,
     rsOASArtemisLevel.value AS OASArtemisLevel,
     rsEmailArtemisLevel.value AS EmailArtemisLevel,
     rsODSArtemisLevel.value AS ODSArtemisLevel,
     rsMachineType.value as MachineType,
     rsVSEHotfixes.Value as VSEHotfixes,
     rsOASEnabled.value as OASEnabled,
     rsAPEnabled.Value as APEnabled ,
     rsEnhancedSPEnabled.VALUE as EnhancedSPEnabled

     FROM @missingItems AS Temptable
      LEFT JOIN [dbo].EPOProductSettings AS rsOASArtemisLevel ON (Temptable.ParentID = rsOASArtemisLevel.ParentID AND
							   	                                rsOASArtemisLevel.SectionName = N'On-Access General' AND
							   	                                rsOASArtemisLevel.SettingName = N'dwHeuristicNetCheckSensitivity')
	    LEFT JOIN [dbo].EPOProductSettings AS rsEmailArtemisLevel ON (Temptable.ParentID = rsEmailArtemisLevel.ParentID AND
							   	                                rsEmailArtemisLevel.SectionName = N'Email General' AND
							   	                                rsEmailArtemisLevel.SettingName = N'dwHeuristicNetCheckSensitivity')
	    LEFT JOIN [dbo].EPOProductSettings AS rsODSArtemisLevel ON (Temptable.ParentID = rsODSArtemisLevel.ParentID AND
							   	                                rsODSArtemisLevel.SectionName = N'On-Demand General' AND
							   	                                rsODSArtemisLevel.SettingName = N'dwHeuristicNetCheckSensitivity')
    	LEFT JOIN [dbo].EPOProductSettings AS rsMachineType ON (Temptable.ParentID = rsMachineType.ParentID AND
							   	                                rsMachineType.SectionName = N'General' AND
							   	                                rsMachineType.SettingName = N'MachineType')
	    LEFT JOIN [dbo].EPOProductSettings AS rsVSEHotfixes ON (Temptable.ParentID = rsVSEHotfixes.ParentID AND
							   	                                rsVSEHotfixes.SectionName = N'General' AND
							   	                                rsVSEHotfixes.SettingName = N'Fixes')
      LEFT JOIN [dbo].EPOProductSettings AS rsOASEnabled ON (Temptable.ParentID = rsOASEnabled.ParentID AND
							   	                                rsOASEnabled.SectionName = N'On-Access General' AND
							   	                                rsOASEnabled.SettingName = N'bEnabled')
	    LEFT JOIN [dbo].EPOProductSettings AS rsAPEnabled ON (Temptable.ParentID = rsAPEnabled.ParentID AND
							   	                                rsAPEnabled.SectionName = N'Access Protection' AND
							   	                                rsAPEnabled.SettingName = N'APEnabled')
      LEFT JOIN [dbo].EPOProductSettings AS rsEnhancedSPEnabled ON (Temptable.ParentID = rsEnhancedSPEnabled.ParentID AND
							   	                                rsEnhancedSPEnabled.SectionName = N'Access Protection' AND
							   	                                rsEnhancedSPEnabled.SettingName = N'bSPEnabled')
  END
END
GO

if not exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[VSECustomEvent]') AND type in (N'U'))
BEGIN
    -- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
    IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
        BEGIN
          CREATE TABLE [dbo].[VSECustomEvent]
          (
            [AutoID]                        [int] NOT NULL IDENTITY (1,1),
            [ParentID]                      [bigint] NOT NULL,  ---corresponds to AutoID in EPOEvents table
            [SensitivityLevel]              [nvarchar] (4) NULL,
            [MD5]                           [nvarchar](50) NULL
            CONSTRAINT [PK_VSECustomEvent] PRIMARY KEY CLUSTERED
            (
              [AutoID] ASC
            )ON [PRIMARY]
          ) ON [PRIMARY]
        END
    -- Else EPOEvents table has INT column then create ParentID column as BIGINT
    ELSE
      BEGIN
        CREATE TABLE [dbo].[VSECustomEvent]
        (
          [AutoID]                        [int] NOT NULL IDENTITY (1,1),
          [ParentID]                      [int] NOT NULL,  ---corresponds to AutoID in EPOEvents table
          [SensitivityLevel]              [nvarchar] (4) NULL,
          [MD5]                           [nvarchar](50) NULL
          CONSTRAINT [PK_VSECustomEvent] PRIMARY KEY CLUSTERED
          (
            [AutoID] ASC
          )ON [PRIMARY]
        ) ON [PRIMARY]
      END

      ALTER TABLE [dbo].[VSECustomEvent] ADD
        CONSTRAINT [FK_VSECustomEvent_EPOEvents] FOREIGN KEY (
          [ParentID]
      ) REFERENCES [dbo].[EPOEvents] (
        [AutoID]
      ) ON DELETE CASCADE ON UPDATE NO ACTION
END
ELSE
BEGIN
    if not exists (select * from information_SCHEMA.columns where Table_name='VSECustomEvent' and column_name='MD5')
    ALTER TABLE [dbo].[VSECustomEvent]
    ADD  MD5 [nvarchar](50) NULL

END
GO