-----------------------------------------------------------
-- VSE_InsertBehaviourBlockEvent (File Block)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertBehaviourBlockEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertBehaviourBlockEvent
GO

-----------------------------------------------------------
-- VSE_InsertEnterceptEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertEnterceptEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertEnterceptEvent
GO

-----------------------------------------------------------
-- VSE_InsertPortBlockEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertPortBlockEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertPortBlockEvent
GO

-----------------------------------------------------------
-- VSE_InsertTaskStatusEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertTaskStatusEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertTaskStatusEvent
GO

-----------------------------------------------------------
-- VSE_InsertVirusDetectionEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertVirusDetectionEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertVirusDetectionEvent
GO

-----------------------------------------------------------
-- VSE_InsertGenericEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertGenericEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertGenericEvent
GO

-----------------------------------------------------------
-- VSE_ReplaceIPV6Zeros (Utility Function)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects
			 WHERE name = 'VSE_ReplaceIPV6Zeros'
			   AND type = 'FN' )
	DROP FUNCTION dbo.VSE_ReplaceIPV6Zeros
GO

-----------------------------------------------------------
-- VSE_HexStrToVarBin  (Utility Function)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects
			 WHERE name = 'VSE_HexStrToVarBin'
			   AND type = 'FN' )
	DROP FUNCTION dbo.VSE_HexStrToVarBin
GO

-----------------------------------------------------------
-- VSE_GetIPV4Address  (Utility Function)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects
			 WHERE name = 'VSE_GetIPV4Address'
			   AND type = 'FN' )
	DROP FUNCTION dbo.VSE_GetIPV4Address
GO


-----------------------------------------------------------
-- VSE_CopyProperties  (For migrating custom props on install/upgrade)
-----------------------------------------------------------
IF EXISTS(SELECT name from sysobjects where name LIKE 'VSE_CopyProperties' and type = 'P')
BEGIN
	DROP PROCEDURE [VSE_CopyProperties]
END
GO