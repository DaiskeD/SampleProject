-- Updating table to support ePO 5.9 DB changes
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[VSECustomEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
  -- If EPOEvents table has BIGINT column then create ParentID column as BIGINT
    IF	EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'EPOEventsMT' AND COLUMN_NAME = 'AutoID')
        AND
        NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE DATA_TYPE = 'BIGINT' AND TABLE_NAME = 'VSECustomEvent' AND COLUMN_NAME = 'ParentID')
    BEGIN

      if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_VSECustomEvent_EPOEvents]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
      BEGIN
        ALTER TABLE [dbo].[VSECustomEvent] DROP CONSTRAINT [FK_VSECustomEvent_EPOEvents];
      END

      ALTER TABLE [dbo].[VSECustomEvent] ALTER COLUMN [ParentID] [Bigint] NOT NULL;

      ALTER TABLE [dbo].[VSECustomEvent] ADD
      CONSTRAINT [FK_VSECustomEvent_EPOEvents] FOREIGN KEY (
        [ParentID]
      ) REFERENCES [dbo].[EPOEventsMT] (
        [AutoID]
      ) ON DELETE CASCADE ON UPDATE NO ACTION

    END
END
GO
