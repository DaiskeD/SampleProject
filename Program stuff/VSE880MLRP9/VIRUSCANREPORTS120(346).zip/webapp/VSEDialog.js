var VSE = window.VSE || {};

VSE.DialogBox = function ()
{
    var dialogDiv = null;
    var shadow = null;

    this.shadow = document.createElement("DIV");
    this.shadow.style.backgroundColor = "black";
    this.shadow.style.position = "absolute";
    this.shadow.style.top = "0px";
    this.shadow.style.left = "0px";
    this.shadow.style.height = "100%";
    this.shadow.style.width = "100%";
    this.shadow.style.zIndex = "9500";
    this.shadow.style.filter = "alpha(opacity=60)"; // IE
    this.shadow.style.opacity = "0.6";
    this.shadow.id = 'divID_DialogShadow'
    this.shadow.style.left = '0px';
    this.shadow.style.top = '0px';
}

VSE.DialogBox.prototype =
{
    setDialogDiv : function(div)
    {
        this.dialogDiv = div;
    }
    ,
    showDialog : function(show)
    {
        if(!validateDialogBox(this))
        {
            return false;
        }

        document.body.appendChild(this.shadow);

        if(show)
        {
            this.shadow.style.visibility = "visible";
            document.body.appendChild(this.dialogDiv);
            this.dialogDiv.style.width = "600px";
            this.dialogDiv.style.visibility = "visible";
        }
        else
        {
            this.dialogDiv.style.visibility = "hidden";
            this.shadow.style.visibility = "hidden";
        }
    }
}

function validateDialogBox(dialog)
{
    if(!dialog.dialogDiv)
    {
        alert("Must call setDialogDiv before using dialog");
        return false;
    }

    return true;
}
