--
--This file is for Removing 'Cookies' from Scanitem list of all existing ODS tasks during Extension upgrade

--Algorithm:
--For each VSE 8.8 ODS task with Scanitem = SpecialCookiesSpyware AND
--a) if the scanitem index of SpecialCookiesSpyware (eg:szscanitem2) is less than the dwscanitemcount-1 (since index starts from 0),
--   it means this is not the last scan item in the list, so we want use this index for the last item in the list, delete this row
--   and decrement the dwscanitemcount by 1.

--b) if the scanitem index of SpecialCookiesSpyware is equal to dwscanitemcount-1, it means this is the last item in the scan item list.
--   In this case, we just decrement the dwscanitemcount by 1, but do not delete the row. Since, only the items with index 0 to dwscanitemcount-1
--   will be displayed in the epo console and also included for scanning in the VSE side, we can leave it in there after decrementing
--   dwscanitemcount by 1.

--c) the scanitem index of SpecialCookiesSpyware is > dwscanitemcount-1, do nothing, since the item is already not considered a valid scan item.
--   It won't be visible in the console and at the same time won't be counted for scanning in VSE client side.


IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[dbo].[VSE_RemoveCookieSpyware_Proc]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[VSE_RemoveCookieSpyware_Proc]
GO

CREATE PROCEDURE [dbo].[VSE_RemoveCookieSpyware_Proc]
(@JoiningID int)

AS
BEGIN

declare @Setting nvarchar(100)

DECLARE TaskSettingsCursor CURSOR FORWARD_ONLY FOR
SELECT SettingName from [EPOTaskSettings] where ParentID = @JoiningID and SectionName = 'ScanItems' and Value ='SpecialCookiesSpyware'

OPEN TaskSettingsCursor

FETCH NEXT FROM TaskSettingsCursor
INTO @Setting

WHILE (@@FETCH_STATUS = 0)
BEGIN
declare @new int
SELECT @new = PARSENAME(REPLACE(@Setting, 'm', '.'), 1)
print @new

declare @count int
select @count = Value from [EPOTaskSettings] where ParentID = @JoiningID and SettingName LIKE 'dwscanitemcount%'
print @count

if(@new < @count-1)
begin
  delete from [EPOTaskSettings]
  where current of TaskSettingsCursor

  UPDATE EPOTaskSettings
  SET [SettingName] = @Setting
  WHERE SettingName = 'szScanItem'+ cast (@count-1 AS nvarchar(100)) and ParentID = @JoiningID

  UPDATE EPOTaskSettings
  Set Value = @count -1 from [EPOTaskSettings] where SettingName = 'dwScanItemCount' and ParentID = @JoiningID
end

else if (@new = @count-1)
Begin
  UPDATE [EPOTaskSettings]
  Set Value = @count -1 from [EPOTaskSettings] where SettingName = 'dwScanItemCount' and ParentID = @JoiningID
End

FETCH NEXT FROM TaskSettingsCursor
	INTO @Setting
END

CLOSE TaskSettingsCursor
DEALLOCATE TaskSettingsCursor

END
GO

--
-- FOR EPO 4.6

if Exists(Select * from sysobjects where id = OBJECT_ID(N'[dbo].[VSE_epo46_Remove_Cookies]') and OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE [dbo].[VSE_epo46_Remove_Cookies]
GO

CREATE PROCEDURE [dbo].[VSE_epo46_Remove_Cookies] ( @taskObjid int)
AS
BEGIN

Declare @Name nvarchar(100)

Declare c2 CURSOR FORWARD_ONLY FOR
Select SettingName From [EPOTaskObjectSettings] where TaskObjectId  = @taskObjid and SectionName = 'ScanItems' and SettingValue ='SpecialCookiesSpyware'

OPEN c2
FETCH NEXT FROM c2 INTO @Name
Print @Name

WHILE(@@FETCH_STATUS = 0)
BEGIN
Declare @index int
Select @index = PARSENAME(REPLACE(@Name,'m','.'),1)
print @index

Declare @Count int
Select @Count = SettingValue from [EPOTaskObjectSettings] where TaskObjectId  = @taskObjid and SectionName = 'ScanItems' and SettingName ='dwScanItemCount'
print @Count

if(@index < @Count-1)
Begin

	DELETE FROM [EPOTaskObjectSettings]
      WHERE CURRENT OF c2

	UPDATE [EPOTaskObjectSettings]
    SET [SettingName] = @Name
    WHERE [SettingName] = 'szScanItem'+CAST(@Count-1 AS nvarchar(100)) AND TaskObjectId  = @taskObjid

	UPDATE [EPOTaskObjectSettings]
    SET [SettingValue] = @Count - 1
    WHERE [SettingName] = 'dwScanItemCount' AND TaskObjectId  = @taskObjid
End

ELSE IF(@index = @Count-1)
Begin
	Print 'Else'
	UPDATE [EPOTaskObjectSettings]
    SET [SettingValue] = @Count - 1
    WHERE [SettingName] = 'dwScanItemCount' AND TaskObjectId  = @taskObjid
End
FETCH NEXT FROM c2 INTO @Name
END

CLOSE c2
DEALLOCATE c2

END
GO
