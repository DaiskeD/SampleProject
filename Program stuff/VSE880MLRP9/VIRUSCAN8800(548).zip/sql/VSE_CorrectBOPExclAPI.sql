UPDATE [EPOPolicySettingValues]
SET [SettingValue] = ''
WHERE (SettingValue)=' '
AND PolicySettingValuesID IN (
SELECT S.PolicySettingValuesID
  FROM [EPOPolicyObjects] O INNER JOIN [EPOPolicyTypes] T ON
	 O.TYPEID = T.TYPEID
  JOIN [EPOPolicyObjectToSettings] OS ON
	 OS.PolicyObjectID = O.PolicyObjectID
  JOIN [EPOPolicySettingValues] S ON
	 S.PolicySettingsID = OS.PolicySettingsID
WHERE TypeTextID = 'VSC700_BufferOverflow_Policies' AND SettingName LIKE 'EnterceptExclusionAPI_%' and T.[FeatureTextID] = 'VIRUSCAN8800')