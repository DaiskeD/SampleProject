
--This file is disabling Cookie Scan on existing policies
--Settings : ScanCookies, bExcludeCookies
--Common for both epo4.5 and epo4.6

UPDATE [EPOPolicySettingValues]
SET SettingValue = 0 where PolicySettingValuesID IN (
SELECT S.PolicySettingValuesID
  FROM [EPOPolicyObjects] O INNER JOIN [EPOPolicyTypes] T ON
	 O.TYPEID = T.TYPEID
  JOIN [EPOPolicyObjectToSettings] OS ON
	 OS.PolicyObjectID = O.PolicyObjectID
  JOIN [EPOPolicySettingValues] S ON
	 S.PolicySettingsID = OS.PolicySettingsID
WHERE TypeTextID = 'VSC700_General_Policies' and  S.SettingName = 'ScanCookies' and T.[FeatureTextID] = 'VIRUSCAN8800')

UPDATE [EPOPolicySettingValues]
SET SettingValue = 1 where PolicySettingValuesID IN (
SELECT S.PolicySettingValuesID
  FROM [EPOPolicyObjects] O INNER JOIN [EPOPolicyTypes] T ON
	 O.TYPEID = T.TYPEID
  JOIN [EPOPolicyObjectToSettings] OS ON
	 OS.PolicyObjectID = O.PolicyObjectID
  JOIN [EPOPolicySettingValues] S ON
	 S.PolicySettingsID = OS.PolicySettingsID
WHERE TypeTextID = 'VSC700_General_Policies' and  S.SettingName = 'bExcludeCookies' and T.[FeatureTextID] = 'VIRUSCAN8800')
