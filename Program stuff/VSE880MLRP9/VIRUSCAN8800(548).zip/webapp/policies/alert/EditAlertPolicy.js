    var AlertManagerServerPath = new Array();
	var AlertType = new Array();
	var bSendToAlertManagerEmail = new Array();
    var bSendToAlertManagerOAS = new Array();
	var bSendToAlertManagerODS = new Array();
	var bSendToAlertManagerUpdate = new Array();
    var bSendToAlertManagerAP = new Array();
    var bSendToAlertManagerNetApp = new Array();
    var bSendToAlertManagerICAP = new Array();
    var bSendToAlertManagerVMODS = new Array();
    var bSendToAlertManagerSAP = new Array();
    var CentralizedAlertingPath = new Array();
	var NoActiveDir = new Array();

    var bLocalEventLog = new Array();
    var bSendSNMP = new Array();
    var SuppressAlertsBelow = new Array();
    var bNoAlertingOptionsChecked = false;

    var g_bStorageModuleInstalled = false;
    var g_bVMModuleInstalled = false;
    var g_bSAPModuleInstalled = false;

    function epoApplyPolicySettings()
    {
        writeHiddenData();

        OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveAlertPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
        return false;
    };

    function fnApplyPolicySuccess()
    {
        fnGoBack();
    };

    function fnApplyPolicyFailure()
    {
        alert("Unable to save policy");
        return false;
    };

   // bState is set to the state of the Disable check box.
    // if bState is false, then the alerting is NOT disabled.
    function fnToggleAlertDestinationOptions()
    {
        var bState = $("ID_DisableAlerting").checked;

        if ( !bNoAlertingOptionsChecked && !bState )
        {
            if ($("radioID_CentralizedAlerting").checked)
            {
                document.getElementById("textboxID_CentralizedAlerting").disabled = false;
            }
            else
            {
                document.getElementById("textboxID_CentralizedAlerting").disabled = true;
            }

            // Don't set radio button automatically if one is already set..
            if ( !($("radioID_CentralizedAlerting").checked ||
                   $("radioID_AMAlerting").checked) )
            {
                $("radioID_CentralizedAlerting").checked = true;
                fnToggleDestinationLabel(1);
            }

        }
        else
        {
            $("radioID_DisableAlerting").checked = true;
            $("radioID_CentralizedAlerting").checked = false;
            $("radioID_AMAlerting").checked = false;
            fnToggleDestinationLabel(0);
            $("textID_AlertingPath").value = "";
            document.getElementById("textboxID_CentralizedAlerting").disabled = true;
        }

        OrionCore.setEnabledById("radioID_CentralizedAlerting", !bState && !bNoAlertingOptionsChecked);
        OrionCore.setEnabledById("radioID_AMAlerting", !bState && !bNoAlertingOptionsChecked);
        OrionCore.setEnabledById("textID_AlertingPath", !bState && !bNoAlertingOptionsChecked);
        OrionCore.setEnabledById("labelID_AMServerPath", !bState && !bNoAlertingOptionsChecked);
        OrionCore.setEnabledById("labelID_CentralAlertPath", !bState && !bNoAlertingOptionsChecked);
        OrionCore.setEnabledById("labelID_Destination", !bState && !bNoAlertingOptionsChecked);

        OrionCore.setEnabledById("checkboxID_NoActiveDir", !bState && $("radioID_AMAlerting").checked && !bNoAlertingOptionsChecked);
    };

    function fnToggleDestinationLabel(iIndex)
    {
        var centralAlertPathLabel = $("labelID_CentralAlertPath");
        var AMServerPathLabel = $("labelID_AMServerPath");
        var destinationLabel = $("labelID_Destination");

        var textboxCentralAlerting = $("textboxID_CentralizedAlerting");
        var textboxAMServer = $("textboxID_AlertManagerServer");
        var textboxGeneric = $("textID_AlertingPath");

        if(iIndex == 1)
        {
            destinationLabel.style.display = 'none';
            AMServerPathLabel.style.display = 'none';
            centralAlertPathLabel.style.display = '';

            textboxGeneric.style.display = 'none';
            textboxCentralAlerting.style.display = '';
            textboxAMServer.style.display = 'none';
            document.getElementById("textboxID_CentralizedAlerting").disabled = false;
        }
        else if(iIndex == 2)
        {
            destinationLabel.style.display = 'none';
            centralAlertPathLabel.style.display = 'none';
            AMServerPathLabel.style.display = '';

            textboxGeneric.style.display = 'none';
            textboxCentralAlerting.style.display = 'none';
            textboxAMServer.style.display = '';
            document.getElementById("textboxID_CentralizedAlerting").disabled = true;
        }
        else
        {
            centralAlertPathLabel.style.display = 'none';
            AMServerPathLabel.style.display = 'none';
            destinationLabel.style.display = '';

            textboxGeneric.style.display = '';
            textboxCentralAlerting.style.display = 'none';
            textboxAMServer.style.display = 'none';
            document.getElementById("textboxID_CentralizedAlerting").disabled = true;
        }
        OrionCore.setEnabledById("checkboxID_NoActiveDir", $("radioID_AMAlerting").checked);
    };

    function fnEnableAlertingUI()
    {
        if(!($("checkboxID_AlertSendToAmOAS").checked) &&
           !($("checkboxID_AlertSendToAmODS").checked) &&
           !($("checkboxID_AlertSendToAmEmail").checked) &&
           !($("checkboxID_AlertSendToAmUpdate").checked) &&
           !($("checkboxID_AlertSendToAmAP").checked) &&
           ((g_bStorageModuleInstalled && !($("checkboxID_AlertSendToAmNetApp").checked)) || !g_bStorageModuleInstalled) &&
           ((g_bStorageModuleInstalled && !($("checkboxID_AlertSendToAmICAP").checked)) || !g_bStorageModuleInstalled) &&
           ((g_bVMModuleInstalled && !($("checkboxID_AlertSendToAmVMODS").checked)) || !g_bVMModuleInstalled) &&
           ((g_bVMModuleInstalled && !($("checkboxID_AlertSendToAmSAP").checked)) || !g_bVMModuleInstalled))
        {
            bNoAlertingOptionsChecked = true;
            
        }
        else
        {
            bNoAlertingOptionsChecked = false;
        }

        $("ID_DisableAlerting").disabled = bNoAlertingOptionsChecked;
        $("radioID_DisableAlerting").disabled = bNoAlertingOptionsChecked;
        $("radioID_CentralizedAlerting").disabled = bNoAlertingOptionsChecked;
        $("radioID_AMAlerting").disabled = bNoAlertingOptionsChecked;
        $("labelID_Destination").disabled = bNoAlertingOptionsChecked;
        $("labelID_CentralAlertPath").disabled = bNoAlertingOptionsChecked;
        $("labelID_AMServerPath").disabled = bNoAlertingOptionsChecked;
        $("textID_AlertingPath").disabled = bNoAlertingOptionsChecked;
        $("textboxID_CentralizedAlerting").disabled = bNoAlertingOptionsChecked;
        $("textboxID_AlertManagerServer").disabled = bNoAlertingOptionsChecked;
        $("checkboxID_NoActiveDir").disabled = bNoAlertingOptionsChecked;
        //Bug 545138 We don't want to disable these as it doesn't match console functionality
        //$("selectID_AlertFilter").disabled = bNoAlertingOptionsChecked;
        //$("checkboxID_AlertLogToEventLog").disabled = bNoAlertingOptionsChecked;
        //$("checkboxID_AlertSendSNMPTrap").disabled = bNoAlertingOptionsChecked;

        fnToggleAlertDestinationOptions();
    }

    function writeHiddenData()
    {
        storePolicyData(g_CurrentPolicyType);
        $("hiddenID_WrkstnAlertSendToAmOAS").value = bSendToAlertManagerOAS[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendToAmOAS").value = bSendToAlertManagerOAS[SERVER_POLICY];
        $("hiddenID_WrkstnAlertSendToAmODS").value = bSendToAlertManagerODS[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendToAmODS").value = bSendToAlertManagerODS[SERVER_POLICY];
        $("hiddenID_WrkstnAlertSendToAmEmail").value = bSendToAlertManagerEmail[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendToAmEmail").value = bSendToAlertManagerEmail[SERVER_POLICY];
        $("hiddenID_WrkstnAlertSendToAmUpdate").value = bSendToAlertManagerUpdate[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendToAmUpdate").value = bSendToAlertManagerUpdate[SERVER_POLICY];
        $("hiddenID_WrkstnAlertSendToAmAP").value = bSendToAlertManagerAP[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendToAmAP").value = bSendToAlertManagerAP[SERVER_POLICY];

        if(g_bStorageModuleInstalled)
        {
            $("hiddenID_WrkstnAlertSendToAmNetApp").value = bSendToAlertManagerNetApp[WRKSTN_POLICY];
            $("hiddenID_ServerAlertSendToAmNetApp").value = bSendToAlertManagerNetApp[SERVER_POLICY];
            $("hiddenID_WrkstnAlertSendToAmICAP").value = bSendToAlertManagerICAP[WRKSTN_POLICY];
            $("hiddenID_ServerAlertSendToAmICAP").value = bSendToAlertManagerICAP[SERVER_POLICY];
        }

        if(g_bVMModuleInstalled)
        {
            $("hiddenID_WrkstnAlertSendToAmVMODS").value = bSendToAlertManagerVMODS[WRKSTN_POLICY];
            $("hiddenID_ServerAlertSendToAmVMODS").value = bSendToAlertManagerVMODS[SERVER_POLICY];
        }

        if(g_bSAPModuleInstalled)
        {
            $("hiddenID_WrkstnAlertSendToAmSAP").value = bSendToAlertManagerSAP[WRKSTN_POLICY];
            $("hiddenID_ServerAlertSendToAmSAP").value = bSendToAlertManagerSAP[SERVER_POLICY];
        }

        $("hiddenID_WrkstnAlertType").value = AlertType[WRKSTN_POLICY];
        $("hiddenID_ServerAlertType").value = AlertType[SERVER_POLICY];
        $("hiddenID_WrkstnCentralizedAlerting").value = CentralizedAlertingPath[WRKSTN_POLICY];
        $("hiddenID_ServerCentralizedAlerting").value = CentralizedAlertingPath[SERVER_POLICY];
        $("hiddenID_WrkstnAlertManagerServerPath").value = AlertManagerServerPath[WRKSTN_POLICY];
        $("hiddenID_ServerAlertManagerServerPath").value = AlertManagerServerPath[SERVER_POLICY];
        $("hiddenID_WrkstnNoActiveDir").value = NoActiveDir[WRKSTN_POLICY];
        $("hiddenID_ServerNoActiveDir").value = NoActiveDir[SERVER_POLICY];
        $("hiddenID_WrkstnAlertFilter").value = SuppressAlertsBelow[WRKSTN_POLICY];
        $("hiddenID_ServerAlertFilter").value = SuppressAlertsBelow[SERVER_POLICY];
        $("hiddenID_WrkstnAlertLogToEventLog").value = bLocalEventLog[WRKSTN_POLICY];
        $("hiddenID_ServerAlertLogToEventLog").value = bLocalEventLog[SERVER_POLICY];
        $("hiddenID_WrkstnAlertSendSNMPTrap").value = bSendSNMP[WRKSTN_POLICY];
        $("hiddenID_ServerAlertSendSNMPTrap").value = bSendSNMP[SERVER_POLICY];
    }

    function storePolicyData(policyType)
    {
        var DisableAlertingCheckBox = $("ID_DisableAlerting");
        var CentralizedAlertingRadio = $("radioID_CentralizedAlerting");
        var NoActiveDirCheckBox = $("checkboxID_NoActiveDir");

        if(!DisableAlertingCheckBox.checked)
        {
            if(CentralizedAlertingRadio.checked)
            {
                AlertType[policyType] = "2";
                CentralizedAlertingPath[policyType] = $("textboxID_CentralizedAlerting").value;
                NoActiveDir[policyType] = false;
            }
            else
            {
                AlertType[policyType] = "4";
                AlertManagerServerPath[policyType] = $("textboxID_AlertManagerServer").value;
                NoActiveDir[policyType] = NoActiveDirCheckBox.checked;
            }
        }
        else
        {
            AlertType[policyType] = "2147483652";
        }

        bSendToAlertManagerEmail[policyType] = $("checkboxID_AlertSendToAmEmail").checked;
        bSendToAlertManagerOAS[policyType] = $("checkboxID_AlertSendToAmOAS").checked;
        bSendToAlertManagerODS[policyType] = $("checkboxID_AlertSendToAmODS").checked;
        bSendToAlertManagerUpdate[policyType] = $("checkboxID_AlertSendToAmUpdate").checked;
        bSendToAlertManagerAP[policyType] = $("checkboxID_AlertSendToAmAP").checked;

        if(g_bStorageModuleInstalled)
        {
            bSendToAlertManagerNetApp[policyType] = $("checkboxID_AlertSendToAmNetApp").checked;
            bSendToAlertManagerICAP[policyType] = $("checkboxID_AlertSendToAmICAP").checked;
        }

        if(g_bVMModuleInstalled)
        {
            bSendToAlertManagerVMODS[policyType] = $("checkboxID_AlertSendToAmVMODS").checked;
        }

        if(g_bSAPModuleInstalled)
        {
            bSendToAlertManagerSAP[policyType] = $("checkboxID_AlertSendToAmSAP").checked;
        }

        bLocalEventLog[policyType] = $("checkboxID_AlertLogToEventLog").checked;
        bSendSNMP[policyType] = $("checkboxID_AlertSendSNMPTrap").checked;
        SuppressAlertsBelow[policyType] = $("selectID_AlertFilter").selectedIndex;
    }

    function displayPolicyData(policyType)
    {
        var iAlertType = parseInt(AlertType[policyType],10);
        var DisableAlertingCheckBox = $("ID_DisableAlerting");
        var AlertingDisabledRadio = $("radioID_DisableAlerting");
        var CentralizedAlertingRadio = $("radioID_CentralizedAlerting");
        var AMAlertingRadio = $("radioID_AMAlerting");
        var NoActiveDirCheckBox = $("checkboxID_NoActiveDir");

        $("textboxID_CentralizedAlerting").value = CentralizedAlertingPath[policyType];
        $("textboxID_AlertManagerServer").value = AlertManagerServerPath[policyType];

        switch(iAlertType)
        {
            case 2:
                DisableAlertingCheckBox.checked = false;
                CentralizedAlertingRadio.checked = true;
                NoActiveDirCheckBox.disabled = true;
                fnToggleDestinationLabel(1);
                break;
            case 4:
                DisableAlertingCheckBox.checked = false;
                AMAlertingRadio.checked = true;
                NoActiveDirCheckBox.checked = NoActiveDir[policyType];
                fnToggleDestinationLabel(2);
                break;
            default:
                DisableAlertingCheckBox.checked = true;
                AlertingDisabledRadio.checked = true;
                fnToggleDestinationLabel(0);
                break;
        }

        $("checkboxID_AlertSendToAmEmail").checked = bSendToAlertManagerEmail[policyType];
        $("checkboxID_AlertSendToAmOAS").checked = bSendToAlertManagerOAS[policyType];
        $("checkboxID_AlertSendToAmODS").checked = bSendToAlertManagerODS[policyType];
        $("checkboxID_AlertSendToAmUpdate").checked = bSendToAlertManagerUpdate[policyType];
        $("checkboxID_AlertSendToAmAP").checked = bSendToAlertManagerAP[policyType];

        if(WRKSTN_POLICY==policyType)
        {
            $("spanID_AlertNetApp").style.display = "none";
            $("spanID_AlertICAP").style.display = "none";
        }
        else
        {
            if(g_bStorageModuleInstalled)
            {
                $("spanID_AlertNetApp").style.display = "";
                $("spanID_AlertICAP").style.display = "";

                $("checkboxID_AlertSendToAmNetApp").checked = bSendToAlertManagerNetApp[policyType];
                $("checkboxID_AlertSendToAmICAP").checked = bSendToAlertManagerICAP[policyType];
            }
            else
            {
                $("spanID_AlertNetApp").style.display = "none";
                $("spanID_AlertICAP").style.display = "none";
            }            
        }

        if(g_bVMModuleInstalled)
        {
            $("spanID_AlertVMODS").style.display = "";

            $("checkboxID_AlertSendToAmVMODS").checked = bSendToAlertManagerVMODS[policyType];
        }
        else
        {            
            $("spanID_AlertVMODS").style.display = "none";
        }

        if(WRKSTN_POLICY==policyType)
        {
            $("spanID_AlertSAP").style.display = "none";
        }
        else
        {
            if(g_bSAPModuleInstalled)
            {
                $("spanID_AlertSAP").style.display = "";

                $("checkboxID_AlertSendToAmSAP").checked = bSendToAlertManagerSAP[policyType];
            }
            else
            {
                $("spanID_AlertSAP").style.display = "none";          
            }
        }

        $("checkboxID_AlertLogToEventLog").checked = bLocalEventLog[policyType];
        $("checkboxID_AlertSendSNMPTrap").checked = bSendSNMP[policyType];
        $("selectID_AlertFilter").selectedIndex = SuppressAlertsBelow[policyType];

        fnEnableAlertingUI();
        fnToggleAlertDestinationOptions();

        _doReadonly();
    }
