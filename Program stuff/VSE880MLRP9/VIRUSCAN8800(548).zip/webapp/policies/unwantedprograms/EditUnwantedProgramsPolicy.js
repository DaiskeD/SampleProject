// globals
var g_WrkstnUPExclusionsAddWidget = null;
var g_WrkstnUserDefinedDetectionsAddWidget = null;
var g_ServerUPExclusionsAddWidget = null;
var g_ServerUserDefinedDetectionsAddWidget = null;
var g_bFormDirty = false;

    // Detection Section Values
var bEnabled = new Array();
var ExtensionMode = new Array();
var szDefaultPlusExtensions = new Array();
var szProgramExtensions = new Array();
    // DAT Detections Section
var bDetectAdware = new Array();
var bDetectDialers = new Array();
var bDetectJokes = new Array();
var bDetectKeyLoggers = new Array();
var bDetectPasswordCrackers = new Array();
var bDetectPotentiallyUnwantedApps = new Array();
var bDetectRemoteAdminTools = new Array();
var bDetectSpyware = new Array();
    // Detection Items sections
var dwDetectionItemCount = new Array();
    // Spy Exclusions Section
var dwSpywareExclCount = new Array();
    // User Detections Section
var Test123 = new Array();
var g_arrListUWPData = new Array();
var g_UserDefinedItemsListWidget;
var addeditUWPDialog = null;
var maximumCountUWPDialog = null;
var g_bNewUWPItem = false;

UWPDataItem = function(obj)
{
    var uwpData = "";
}

function epoApplyPolicySettings()
{
    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveUnwantedProgramsPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

// ***************************************************************************
// Wrkstn_UPExclAddCallback - Called whenever a wrkstn exclusion is added
// ***************************************************************************
function Wrkstn_UPExclAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("wrkstn_upexclusionslist_awrow_", "");
        var ExclusionElement = $("wrkstn_up_exclusion_"+itemID);

        // Add Event Handlers
        if(ExclusionElement != null)
        {
            OrionEvent.registerHandlerById("wrkstn_up_exclusion_" + itemID, validatePolicy, null, "keyup", false);
        }
    }
}

// ***************************************************************************
// Wrkstn_UPExclAddCallback - Called whenever a server exclusion is added
// ***************************************************************************
function Server_UPExclAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("server_upexclusionslist_awrow_", "");
        var ExclusionElement = $("server_up_exclusion_"+itemID);

        // Add Event Handlers
        if(ExclusionElement != null)
        {
            OrionEvent.registerHandlerById("server_up_exclusion_" + itemID, validatePolicy, null, "keyup", false);
        }
    }
}

function UPExclRemoveCallback()
{
    stateChangeHandler(true, OrionForm.isFormValid());
}

function userDefinedDetectionsAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var szPolicyType = newDiv.id.substring(0, 7);
        if(szPolicyType != "wrkstn_" && szPolicyType != "server_")
        {
            return;
        }

        var itemID = newDiv.id.replace(szPolicyType + "userdefined_detectionslist_awrow_", "");
        var filenameElement = $(szPolicyType + "userdefined_filename_" + itemID);
        var descriptionElement = $(szPolicyType + "userdefined_description_" + itemID);
        var hiddenValueName = szPolicyType + "userdefined_detectionslist_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            var endpos = hiddenValue.indexOf( ":" );

            if(endpos != -1)
            {
                filenameElement.value = hiddenValue.substr(0, endpos);
                descriptionElement.value = hiddenValue.substr(endpos + 1);
            }
            else
            {
                filenameElement.value = "";
                descriptionElement.value = "";
            }
        }

        // Add Event Handlers
        if(filenameElement != null)
        {
            OrionEvent.registerHandlerById(filenameElement.id, validatePolicy, null, "keyup", false);
            OrionForm.addFieldValidators(filenameElement.id, [validateUserDefinedItem]);
        }

        if(descriptionElement != null)
        {
            OrionEvent.registerHandlerById(descriptionElement.id,
                                           function() {userDefinedDescriptionKeyup(descriptionElement, filenameElement);},
                                           null,
                                           "keyup",
                                           false);
            OrionEvent.registerHandlerById(descriptionElement.id, validatePolicy, null, "keyup", false);
        }
    }
}
function userDefinedDetectionsRemoveCallback(newDiv)
{
    stateChangeHandler(true, OrionForm.isFormValid());
}

function userDefinedDescriptionKeyup(UDDescriptionElement, UDFilenameElement)
{
    if(UDDescriptionElement != null && UDFilenameElement != null)
    {
        OrionForm.setFieldRequired(UDFilenameElement.id, UDDescriptionElement.value != "");
    }
}

function Wrkstn_writeUPExclusions()
{
    var UPExclusionsList = g_WrkstnUPExclusionsAddWidget.getList();
    var exclusions = "";

    for(var i=0; i < UPExclusionsList.length; ++i)
    {
        var currentItemID = UPExclusionsList[i].replace("wrkstn_upexclusionslist_awrow_", "");
        var currentExclusion = $("wrkstn_up_exclusion_"+currentItemID);

        if(currentExclusion.value != "")
        {
            exclusions += currentExclusion.value;

            if(i < (UPExclusionsList.length-1))
            {
                exclusions += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    $("hiddenID_WrkstnUnwantedProgramsExclusions").value = exclusions;
}

function Server_writeUPExclusions()
{
    var UPExclusionsList = g_ServerUPExclusionsAddWidget.getList();
    var exclusions = "";

    for(var i=0; i < UPExclusionsList.length; ++i)
    {
        var currentItemID = UPExclusionsList[i].replace("server_upexclusionslist_awrow_", "");
        var currentExclusion = $("server_up_exclusion_"+currentItemID);

        if(currentExclusion.value != "")
        {
            exclusions += currentExclusion.value;

            if(i < (UPExclusionsList.length-1))
            {
                exclusions += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    $("hiddenID_ServerUnwantedProgramsExclusions").value = exclusions;
}

function Wrkstn_writeUserDefinedDetections()
{
    var szUserDefinedDetectionsList = "";
    for(var i = 0; i < g_arrListUWPData[0].length; ++i)
    {
        szUserDefinedDetectionsList += g_arrListUWPData[0][i].uwpData;
        if((i+1) < g_arrListUWPData[0].length)
        {
            szUserDefinedDetectionsList += Constants.LIST_TOKEN_SPLITTER;
        }
    }
    $("hiddenID_WrkstnUserDefinedDetections").value = szUserDefinedDetectionsList;
}

function Server_writeUserDefinedDetections()
{
    var szUserDefinedDetectionsList = "";
    for(var i = 0; i < g_arrListUWPData[1].length; ++i)
    {
        szUserDefinedDetectionsList += g_arrListUWPData[1][i].uwpData;
        if((i+1) < g_arrListUWPData[1].length)
        {
            szUserDefinedDetectionsList += Constants.LIST_TOKEN_SPLITTER;
        }
    }
    $("hiddenID_ServerUserDefinedDetections").value = szUserDefinedDetectionsList;
}

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    $("hiddenID_WrkstnDetectSpyware").value = bDetectSpyware[WRKSTN_POLICY];
    $("hiddenID_ServerDetectSpyware").value = bDetectSpyware[SERVER_POLICY];
    $("hiddenID_WrkstnDetectAdware").value = bDetectAdware[WRKSTN_POLICY];
    $("hiddenID_ServerDetectAdware").value = bDetectAdware[SERVER_POLICY];
    $("hiddenID_WrkstnDetectRemoteAdminTools").value = bDetectRemoteAdminTools[WRKSTN_POLICY];
    $("hiddenID_ServerDetectRemoteAdminTools").value = bDetectRemoteAdminTools[SERVER_POLICY];
    $("hiddenID_WrkstnDetectDialers").value = bDetectDialers[WRKSTN_POLICY];
    $("hiddenID_ServerDetectDialers").value = bDetectDialers[SERVER_POLICY];
    $("hiddenID_WrkstnDetectPasswordCrackers").value = bDetectPasswordCrackers[WRKSTN_POLICY];
    $("hiddenID_ServerDetectPasswordCrackers").value = bDetectPasswordCrackers[SERVER_POLICY];
    $("hiddenID_WrkstnDetectJokes").value = bDetectJokes[WRKSTN_POLICY];
    $("hiddenID_ServerDetectJokes").value = bDetectJokes[SERVER_POLICY];
    $("hiddenID_WrkstnDetectKeyLoggers").value = bDetectKeyLoggers[WRKSTN_POLICY];
    $("hiddenID_ServerDetectKeyLoggers").value = bDetectKeyLoggers[SERVER_POLICY];
    $("hiddenID_WrkstnDetectPUPs").value = bDetectPotentiallyUnwantedApps[WRKSTN_POLICY];
    $("hiddenID_ServerDetectPUPs").value = bDetectPotentiallyUnwantedApps[SERVER_POLICY];

    Wrkstn_writeUPExclusions();
    Wrkstn_writeUserDefinedDetections();
    Server_writeUPExclusions();
    Server_writeUserDefinedDetections();
}
function storePolicyData(policyType)
{
        // DAT Detections Section
    bDetectSpyware[policyType] = $("checkboxID_DetectSpyware").checked;
    bDetectAdware[policyType] = $("checkboxID_DetectAdware").checked;
    bDetectRemoteAdminTools[policyType] = $("checkboxID_DetectRemoteAdminTools").checked;
    bDetectDialers[policyType] = $("checkboxID_DetectDialers").checked;
    bDetectPasswordCrackers[policyType] = $("checkboxID_DetectPasswordCrackers").checked;
    bDetectJokes[policyType] = $("checkboxID_DetectJokes").checked;
    bDetectKeyLoggers[policyType] = $("checkboxID_DetectKeyLoggers").checked;
    bDetectPotentiallyUnwantedApps[policyType] = $("checkboxID_DetectPUPs").checked;

    // Store User Defined unwanted items data
    var userDefinedItems = g_UserDefinedItemsListWidget.getItemList();
    g_arrListUWPData[policyType] = new Array();
    for(i = 0; i < userDefinedItems.length; ++i)
    {
        g_arrListUWPData[policyType][i] = userDefinedItems[i].itemData;                            
    }
}

function displayPolicyData(policyType)
{
        // DAT Detections Section
    $("checkboxID_DetectSpyware").checked = bDetectSpyware[policyType];
    $("checkboxID_DetectAdware").checked = bDetectAdware[policyType];
    $("checkboxID_DetectRemoteAdminTools").checked = bDetectRemoteAdminTools[policyType];
    $("checkboxID_DetectDialers").checked = bDetectDialers[policyType];
    $("checkboxID_DetectPasswordCrackers").checked = bDetectPasswordCrackers[policyType];
    $("checkboxID_DetectJokes").checked = bDetectJokes[policyType];
    $("checkboxID_DetectKeyLoggers").checked = bDetectKeyLoggers[policyType];
    $("checkboxID_DetectPUPs").checked = bDetectPotentiallyUnwantedApps[policyType];

    if(policyType == 0)
    {
        $("wrkstn_upexclusionslist").style.display = "";
        $("server_upexclusionslist").style.display = "none";
    }
    else
    {
        $("wrkstn_upexclusionslist").style.display = "none";
        $("server_upexclusionslist").style.display = "";
    }

    populateUserDefinedDetectionsList();
    _doReadonly();
}

function validateUserDefinedItem(szItem)
{
    var r;

	r = szItem.indexOf("/");

	if(r == -1)
		r = szItem.indexOf("\\");

    if(r == -1)
		r = szItem.indexOf("\*");

	if(r == -1)
		r = szItem.indexOf("?");

	if(r == -1)
		r = szItem.indexOf("\"");

	if(r == -1)
		r = szItem.indexOf("|");

    if(r == -1)
		r = szItem.indexOf("<");

    if(r == -1)
		r = szItem.indexOf(">");

    if(r == -1)
		r = szItem.indexOf(":");

    if(r == -1)
		return true;

	return false;
}

function UserDefinedItem_AddCallback(newRow)
{
    if(newRow != null)
    {
        var itemID = newRow.id.replace("divID_UWPUserDefinedItemsList_lwrow_", "");
        var uwpFilenameElement = $("uwp_userdefined_filename_" + itemID);
        var uwpDescriptionElement = $("uwp_userdefined_description_" + itemID);
        var hiddenValue = "";

        var ruleItem = g_UserDefinedItemsListWidget.getItem(newRow.id);
        if(ruleItem != null)
        {
            hiddenValue = ruleItem.itemData.uwpData;
        }

        var endOfFilename = hiddenValue.indexOf( ":" );

        if(endOfFilename != -1)
        {
            uwpFilenameElement.innerHTML = hiddenValue.substr(0, endOfFilename);
            uwpDescriptionElement.innerHTML = hiddenValue.substr(endOfFilename + 1);
        }
        else
        {
            uwpFilenameElement.value = "";
            uwpDescriptionElement.value = "";
        }

        validatePolicy();
    }
}

function userDefinedItemUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var UWPItems = g_UserDefinedItemsListWidget.getItemList();
    g_arrListUWPData[g_CurrentPolicyType] = new Array();
    for(i = 0; i < UWPItems.length; ++i)
    {
        g_arrListUWPData[g_CurrentPolicyType][i] = UWPItems[i].itemData;
    }

    populateUserDefinedDetectionsList();
}

function userDefinedItemRemoveCallback()
{
    validatePolicy();
}

// ************************************************************************
// ************************************************************************
// Add/Edit UWP DialogBox support code
// ************************************************************************
// ************************************************************************
function onAddEditUWPOK()
{
    addeditUWPDialog.showDialog(false);


    var szUWPItem = $("textboxID_userdefined_filename").value + ":" +  $("textboxID_userdefined_description").value;
    var uwpDataItem = new UWPDataItem();
    uwpDataItem.uwpData = szUWPItem;

    if(g_bNewUWPItem)
    {
        var item = new VSE.ListItem2();
        item.itemData = uwpDataItem;
        g_UserDefinedItemsListWidget.add(item);
    }
    else
    {
        g_UserDefinedItemsListWidget.getSelected().itemData = uwpDataItem;
        g_UserDefinedItemsListWidget.selectedRowUpdate();
    }

    g_bFormDirty = true;
}

function onAddEditExclCancel()
{
    addeditUWPDialog.showDialog(false);
}

function onMaximumCountUWPOk()
{
    maximumCountUWPDialog.showDialog(false);
}

function AddUWPItem_onclick()
{
    //if reached the max limit of UWP items, do not allow the adding of more
    var userDefinedItems = g_UserDefinedItemsListWidget.getItemList();
    if (userDefinedItems.length >= 200)
    {
        maximumCountUWPDialog.showDialog(true);
        maximumCountUWPDialog.setWidth("300px");
    }
    else
    {
        g_bNewUWPItem = true;
        addeditUWPDialog.showDialog(true);
        addeditUWPDialog.setWidth("400px");

        $("textboxID_userdefined_filename").value = "";
        $("textboxID_userdefined_description").value = "";

        validateUWPItem();
    }

}

function EditUWPItem_onclick()
{
    g_bNewUWPItem = false;

    var selectedItem = g_UserDefinedItemsListWidget.getSelected();
    if( selectedItem == null)
    {
        return;
    }

    var szUWPItem = selectedItem.itemData.uwpData;
    if(szUWPItem == "")
    {
        return;
    }

    addeditUWPDialog.showDialog(true);
    addeditUWPDialog.setWidth("400px");

    $("textboxID_userdefined_filename").value = "";
    $("textboxID_userdefined_description").value = "";

    var endOfFilename = szUWPItem.indexOf( ":" );
    if(endOfFilename != -1)
    {
        $("textboxID_userdefined_filename").value = szUWPItem.substr(0, endOfFilename);
        $("textboxID_userdefined_description").value = szUWPItem.substr(endOfFilename + 1);
    }

    validateUWPItem();
}

function RemoveUWPItem_onclick()
{
    g_UserDefinedItemsListWidget.removeSelected();
    g_bFormDirty = true;
    validatePolicy();
}

function ClearUWPItem_onclick()
{
    g_UserDefinedItemsListWidget.clearList();
    g_bFormDirty = true;
    validatePolicy();
}

function validateUWPItem()
{
    var valid = true;
    $("UWP_filename_empty").style.display = "none";
    $("UWP_filename_error").style.display = "none";

    if($("textboxID_userdefined_filename").value == "")
    {
        $("UWP_filename_empty").style.display = "";
        valid = false;
    }
    else
    {
        valid = validateUserDefinedItem($("textboxID_userdefined_filename").value);
        if(!valid)
        {
            $("UWP_filename_error").style.display = "";
        }
    }

    $("buttonID_addEditUWPItemOK").disabled = !valid;
}