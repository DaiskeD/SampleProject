// For wFlags..
var g_LOG_SETTINGS           = 16;    // (0x0010)
var g_LOG_SUMMARY            = 32;    // (0x0020)
var g_LOG_ENCRYPT_FAILS      = 256;   // (0x0100)

// "ExtensionMode" enumeration
var g_ExtensionMode = 0;
var g_AllFiles      = 1;
var g_DefaultPlus   = 2;
var g_Default       = 3;
var g_Specified     = 4;

var ACTION_VALUE_INVALID	= 0;
var ACTION_VALUE_CONTINUE	= 1;
var ACTION_VALUE_PROMPT  	= 2;
var ACTION_VALUE_MOVE		= 3;
var ACTION_VALUE_DELETE		= 4;
var ACTION_VALUE_CLEAN		= 5;
var ACTION_VALUE_DELETE_MAIL= 6;

var g_iCurrentPrimaryActionValue 			= 0;
var g_iCurrentPrimaryActionUnwantedValue 	= 0;
var g_iCurrentSecondaryActionValue			= 0;
var g_iCurrentSecondaryActionUnwantedValue	= 0;

// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;

var g_PromptActionFlags1    = 0;
var g_PromptActionClean     = 1;        // (0x0001)
var g_PromptActionDelete    = 2;        // (0x0002)
var g_PromptActionMove      = 4;        // (0x0004)
var g_PromptActionDeleteMail= 32;		// 0x0020

    // Detection Section Values
var bEnabled = new Array();
var ExtensionMode = new Array();
var szDefaultPlusExtensions = new Array();
var szProgramExtensions = new Array();
var dwHeuristicNetCheckSensitivity = new Array();

    // Advanced Section Values
var dwMacroHeuristicsLevel = new Array();
var dwProgramHeuristicsLevel = new Array();
var MultipleExtensionsHeuristic = new Array();
var ScanArchives = new Array();
var ScanMessageBodies = new Array();
var ScanMime = new Array();

    // Action Section Values
var uAction = new Array();
var uSecAction = new Array();
var szMoveFolder = new Array();
var dwPromptButton = new Array();

    // Alert Section Values
var bDisplayMessage = new Array();
var bSendMailToUser = new Array();
var szCustomMessage = new Array();
var szSendBody = new Array();
var szSendCc = new Array();
var szSendSubject = new Array();
var szSendTo = new Array();

    // Spyware Section Values
var ApplyNVP = new Array();
var uAction_Program = new Array();
var uSecAction_Program = new Array();
    
    // Reports Section Values
var bLogToFile = new Array();
var bLimitSize = new Array();
var dwLogEvent = new Array();
var dwMaxLogSizeMB = new Array();
var LogFileFormat = new Array();
var szLogFileName = new Array();

    // Notes Section Values
var NOTES_OAScanServerDataBases = new Array();
var NOTES_OAScanServerMail = new Array();
var NOTES_ServerMailFolder = new Array();
var NOTES_szNotesAppsToExclude = new Array();

function epoApplyPolicySettings()
{
    writeHiddenData();

    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveEmailScanPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
	for (var i = 0; i < selectID_CurrentAction.length; i++)
	{
		if ( parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue) )
		{
			selectID_CurrentAction.selectedIndex = i;
		}
	}
}

function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
	for(var i=0; i<selectID_CurrentSecondaryAction.length;i++)
	{
		if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
		{
			selectID_CurrentSecondaryAction.selectedIndex = i;
		}
	}
}

function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if( selectID_CurrentSecondaryAction == g_secondaryActionSelect )
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted )
    {
        g_iCurrentSecondaryActionProgramValue = iSecondaryValue;
    }

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);

    fnTogglePromptOptions( );
}

function fnTogglePromptOptions( )
{
    var bPromptState;
    var bEnabled = document.getElementById("checkboxID_DisplayMessage").checked;

    var PrimaryActionValue = document.getElementById("selectID_ThreatPrimaryAction").value;
    var SecondaryActionValue = document.getElementById("selectID_ThreatSecondaryAction").value;
    var PrimaryProgramActionValue = document.getElementById("selectID_UnwantedPrimaryAction").value;
    var SecondaryProgramActionValue = document.getElementById("selectID_UnwantedSecondaryAction").value;

    bPromptState =  ! ((PrimaryActionValue == ACTION_VALUE_PROMPT) ||
                       (SecondaryActionValue == ACTION_VALUE_PROMPT) ||
                       (PrimaryProgramActionValue == ACTION_VALUE_PROMPT)  ||
                       (SecondaryProgramActionValue == ACTION_VALUE_PROMPT ));

    document.getElementById("checkboxID_DisplayMessage").disabled = bPromptState;
    document.getElementById("textboxID_CustomMessage").disabled = bPromptState || !bEnabled;
}

function fnDisplayMessageChange()
{
    fnTogglePromptOptions();
    validatePolicy();
}

function fnToggleSendMailToUserOptions()
{
    if (document.getElementById("checkboxID_SendMailToUser").checked)
    {
		document.getElementById("ID_SendMailToUserOptions").style.display = "block";
        document.getElementById("textboxID_SendTo").disabled = false;
        document.getElementById("textboxID_SendCc").disabled = false;
        document.getElementById("textboxID_SendSubject").disabled = false;
        document.getElementById("textboxID_SendBody").disabled = false;         
    }

	else
    {
		document.getElementById("ID_SendMailToUserOptions").style.display = "none";
        document.getElementById("textboxID_SendTo").disabled = true;
        document.getElementById("textboxID_SendCc").disabled = true;
        document.getElementById("textboxID_SendSubject").disabled = true;
        document.getElementById("textboxID_SendBody").disabled = true;
    }
}

function fnSendMailToUserChange()
{
	fnToggleSendMailToUserOptions();
    validatePolicy();
}

function fnApplyNVPChange()
{
    fnToggleApplyNVPState();
    validatePolicy();
}

function fnToggleApplyNVPState()
{
    if (document.getElementById("checkboxID_ApplyNVP").checked)
    {
        document.getElementById("selectID_UnwantedPrimaryAction").disabled = false;

        if((document.getElementById("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_CONTINUE)&&
           (document.getElementById("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_PROMPT)&&
           (document.getElementById("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_DELETE_MAIL))
        {
            document.getElementById("selectID_UnwantedSecondaryAction").disabled = false;
        }
        else
        {
            document.getElementById("selectID_UnwantedSecondaryAction").disabled = true;
        }
    }
    else
    {
        document.getElementById("selectID_UnwantedPrimaryAction").disabled = true;
        document.getElementById("selectID_UnwantedSecondaryAction").disabled = true;
    }
}

function validateFileTypes(szFileTypes)
{
    var valid = true;

    if(szFileTypes != "")
    {
        // convert whitespace to spaces
        szFileTypes.replace(/\W+/g,' ');
        var szFileTypeTokens = szFileTypes.split(" ");

        var r = szFileTypes.indexOf("/");

        if (r == -1)
            r = szFileTypes.indexOf("\"");

        if (r == -1)
            r = szFileTypes.indexOf("|");

        if (r == -1)
            r = szFileTypes.indexOf("<");

        if (r == -1)
            r = szFileTypes.indexOf(">");

        if (r == -1)
            r = szFileTypes.indexOf("\\");

        if(r != -1)
        {
            valid = false;
        }

        for(var i=0; valid && (i < szFileTypeTokens.length); ++i)
        {
            if(szFileTypeTokens[i].length > 3)
            {
                valid = false;
            }
            else if(szFileTypeTokens[i] != ":::") 
            {
                r = szFileTypeTokens[i].indexOf(":");
                if (r != -1)
                {
                    valid = false;
                }
            }
        }

    }

    return valid;
}

function validateMailFolder(szFolderText)
{

	var szText = new String(szFolderText);
	var badChars = new String("*?/<>|\"\b");

	switch(szText.charAt(0))
	{
		case " ":
		case ":":
		case "\\":
			return false;    
	}

	for(var i = 0; badChars.charAt(i); ++i )
	{
		if(szText.indexOf(badChars.charAt(i))>0)
		{
			return false;
		}
	}

	return true;
}

// *******************************************************************
// removeDuplicateExtensions - Sorts and removes duplicates from list
//
// Input: szExtensions - whitespace delimited list of extensions
//
// Returns: A space delimited sorted list of extensions with duplicates
// removed.
// *******************************************************************
function removeDuplicateExtensions(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/\s+/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length;)
    {
        var szCurrentItem = szExtItems[i];
        szReturn += szCurrentItem;
        ++i;
        while(i < szExtItems.length && szCurrentItem == szExtItems[i])
        {
            ++i;
        }

        if(i < szExtItems.length)
        {
            szReturn += " ";
        }
    }

    return szReturn;
}

// *******************************************************************
// removeNoExtensionMarker - Removes all ::: entries
//
// Input: szExtensions - whitespace delimited list of extensions
//
// Returns: A space delimited list of extensions with ::: removed
// *******************************************************************
function removeNoExtensionMarker(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/\s+/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length; ++i)
    {
        if(szExtItems[i] != ":::")
        {
            szReturn += szExtItems[i];
        }

        if(i < szExtItems.length - 1 && szReturn != "")
        {
            szReturn += " ";
        }
    }

    return szReturn;
}

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);

        // Detection Section Values
    $("hiddenID_WrkstnEnableEmailScanning").value = bEnabled[WRKSTN_POLICY];
    $("hiddenID_ServerEnableEmailScanning").value = bEnabled[SERVER_POLICY];
    $("hiddenID_WrkstnExtensionMode").value = ExtensionMode[WRKSTN_POLICY];
    $("hiddenID_ServerExtensionMode").value = ExtensionMode[SERVER_POLICY];
    $("hiddenID_WrkstnDefaultPlusExtensions").value = removeDuplicateExtensions(szDefaultPlusExtensions[WRKSTN_POLICY]);
    $("hiddenID_ServerDefaultPlusExtensions").value = removeDuplicateExtensions(szDefaultPlusExtensions[SERVER_POLICY]);
    $("hiddenID_WrkstnProgramExtensions").value = removeDuplicateExtensions(szProgramExtensions[WRKSTN_POLICY]);
    $("hiddenID_ServerProgramExtensions").value = removeDuplicateExtensions(szProgramExtensions[SERVER_POLICY]);
    $("hiddenID_WrkstnHeuristicSensitivity").value = dwHeuristicNetCheckSensitivity[WRKSTN_POLICY];
    $("hiddenID_ServerHeuristicSensitivity").value = dwHeuristicNetCheckSensitivity[SERVER_POLICY];

        // Advanced Section Values
    $("hiddenID_WrkstnProgramHeuristics").value = dwProgramHeuristicsLevel[WRKSTN_POLICY];
    $("hiddenID_ServerProgramHeuristics").value = dwProgramHeuristicsLevel[SERVER_POLICY];
    $("hiddenID_WrkstnMacroHeuristics").value = dwMacroHeuristicsLevel[WRKSTN_POLICY];
    $("hiddenID_ServerMacroHeuristics").value = dwMacroHeuristicsLevel[SERVER_POLICY];
    $("hiddenID_WrkstnExtensionHeuristics").value = MultipleExtensionsHeuristic[WRKSTN_POLICY];
    $("hiddenID_ServerExtensionHeuristics").value = MultipleExtensionsHeuristic[SERVER_POLICY];
    $("hiddenID_WrkstnScanArchives").value = ScanArchives[WRKSTN_POLICY];
    $("hiddenID_ServerScanArchives").value = ScanArchives[SERVER_POLICY];
    $("hiddenID_WrkstnScanMime").value = ScanMime[WRKSTN_POLICY];
    $("hiddenID_ServerScanMime").value = ScanMime[SERVER_POLICY];

        // Action Section Values
    $("hiddenID_WrkstnThreatPrimaryAction").value = uAction[WRKSTN_POLICY];
    $("hiddenID_ServerThreatPrimaryAction").value = uAction[SERVER_POLICY];
    $("hiddenID_WrkstnThreatSecondaryAction").value = uSecAction[WRKSTN_POLICY];
    $("hiddenID_ServerThreatSecondaryAction").value = uSecAction[SERVER_POLICY];
    $("hiddenID_WrkstnMoveFolder").value = szMoveFolder[WRKSTN_POLICY];
    $("hiddenID_ServerMoveFolder").value = szMoveFolder[SERVER_POLICY];
    $("hiddenID_WrkstnPromptButton").value = dwPromptButton[WRKSTN_POLICY];
    $("hiddenID_ServerPromptButton").value = dwPromptButton[SERVER_POLICY];

        // Alert Section Values
    $("hiddenID_WrkstnSendMailToUser").value = bSendMailToUser[WRKSTN_POLICY];
    $("hiddenID_ServerSendMailToUser").value = bSendMailToUser[SERVER_POLICY];
    $("hiddenID_WrkstnSendTo").value = szSendTo[WRKSTN_POLICY];
    $("hiddenID_ServerSendTo").value = szSendTo[SERVER_POLICY];
    $("hiddenID_WrkstnSendCc").value = szSendCc[WRKSTN_POLICY];
    $("hiddenID_ServerSendCc").value = szSendCc[SERVER_POLICY];
    $("hiddenID_WrkstnSendSubject").value = szSendSubject[WRKSTN_POLICY];
    $("hiddenID_ServerSendSubject").value = szSendSubject[SERVER_POLICY];
    $("hiddenID_WrkstnSendBody").value = szSendBody[WRKSTN_POLICY];
    $("hiddenID_ServerSendBody").value = szSendBody[SERVER_POLICY];
    $("hiddenID_WrkstnDisplayMessage").value = bDisplayMessage[WRKSTN_POLICY];
    $("hiddenID_ServerDisplayMessage").value = bDisplayMessage[SERVER_POLICY];
    $("hiddenID_WrkstnCustomMessage").value = szCustomMessage[WRKSTN_POLICY];
    $("hiddenID_ServerCustomMessage").value = szCustomMessage[SERVER_POLICY];
    $("hiddenID_WrkstnScanMessageBodies").value = ScanMessageBodies[WRKSTN_POLICY];
    $("hiddenID_ServerScanMessageBodies").value = ScanMessageBodies[SERVER_POLICY];

        // Spyware Section Values
    $("hiddenID_WrkstnScanApplyNVP").value = ApplyNVP[WRKSTN_POLICY];
    $("hiddenID_ServerScanApplyNVP").value = ApplyNVP[SERVER_POLICY];
    $("hiddenID_WrkstnUnwantedPrimaryAction").value = uAction_Program[WRKSTN_POLICY];
    $("hiddenID_ServerUnwantedPrimaryAction").value = uAction_Program[SERVER_POLICY];
    $("hiddenID_WrkstnUnwantedSecondaryAction").value = uSecAction_Program[WRKSTN_POLICY];
    $("hiddenID_ServerUnwantedSecondaryAction").value = uSecAction_Program[SERVER_POLICY];

        // Reports Section Values
    $("hiddenID_WrkstnLogToFile").value = bLogToFile[WRKSTN_POLICY];
    $("hiddenID_ServerLogToFile").value = bLogToFile[SERVER_POLICY];
    $("hiddenID_WrkstnLogFileName").value = szLogFileName[WRKSTN_POLICY];
    $("hiddenID_ServerLogFileName").value = szLogFileName[SERVER_POLICY];
    $("hiddenID_WrkstnLimitLogFileSize").value = bLimitSize[WRKSTN_POLICY];
    $("hiddenID_ServerLimitLogFileSize").value = bLimitSize[SERVER_POLICY];
    $("hiddenID_WrkstnMaxLogSizeMB").value = dwMaxLogSizeMB[WRKSTN_POLICY];
    $("hiddenID_ServerMaxLogSizeMB").value = dwMaxLogSizeMB[SERVER_POLICY];
    $("hiddenID_WrkstnLogFileFormat").value = LogFileFormat[WRKSTN_POLICY];
    $("hiddenID_ServerLogFileFormat").value = LogFileFormat[SERVER_POLICY];
    $("hiddenID_WrkstnLogEvent").value = dwLogEvent[WRKSTN_POLICY];
    $("hiddenID_ServerLogEvent").value = dwLogEvent[SERVER_POLICY];

        // Notes Section Values
    $("hiddenID_WrkstnNotesScanServerDBS").value = NOTES_OAScanServerDataBases[WRKSTN_POLICY];
    $("hiddenID_ServerNotesScanServerDBS").value = NOTES_OAScanServerDataBases[SERVER_POLICY];
    $("hiddenID_WrkstnNotesScanServerMail").value = NOTES_OAScanServerMail[WRKSTN_POLICY];
    $("hiddenID_ServerNotesScanServerMail").value = NOTES_OAScanServerMail[SERVER_POLICY];
    $("hiddenID_WrkstnNotesServerMailFolder").value = NOTES_ServerMailFolder[WRKSTN_POLICY];
    $("hiddenID_ServerNotesServerMailFolder").value = NOTES_ServerMailFolder[SERVER_POLICY];
    $("hiddenID_WrkstnNotesAppsToExclude").value = NOTES_szNotesAppsToExclude[WRKSTN_POLICY];
    $("hiddenID_ServerNotesAppsToExclude").value = NOTES_szNotesAppsToExclude[SERVER_POLICY];
}

function storePolicyData(policyType)
{
        // Detection Section Values
    bEnabled[policyType] = $("checkboxID_ScanEnabled").checked;
    szDefaultPlusExtensions[policyType] = $("textareaID_AdditionalFileTypes").value;
    if($("checkboxID_AdditionalNoExtension").checked)
    {
        szDefaultPlusExtensions[policyType] += " :::";
    }

    szProgramExtensions[policyType] = $("textareaID_SpecifiedFileTypes").value;
    if($("checkboxID_SpecifiedNoExtension").checked)
    {
        szProgramExtensions[policyType] += " :::";
    }

    if ($("radioID_AllFiles").checked)
    {
        ExtensionMode[policyType] = g_AllFiles;
    }
    else if($("radioID_DefaultAndSpecified").checked &&
            !$("checkboxID_ScanForMarcros").checked)
    {
        ExtensionMode[policyType] = g_Default;
    }
    else if($("radioID_DefaultAndSpecified").checked &&
            $("checkboxID_ScanForMarcros").checked)
    {
        ExtensionMode[policyType] = g_DefaultPlus;
    }
    else
    {
        ExtensionMode[policyType] = g_Specified;
    }

    dwHeuristicNetCheckSensitivity[policyType] = $("selectID_HeuristicSensitivity").value;

        // Advanced Section Values
    dwMacroHeuristicsLevel[policyType] = $("checkboxID_MacroHeuristics").checked;
    dwProgramHeuristicsLevel[policyType] = $("checkboxID_ProgramHeuristics").checked;
    MultipleExtensionsHeuristic[policyType] = $("checkboxID_ExtensionHeuristics").checked;
    ScanArchives[policyType] = $("checkboxID_ScanArchives").checked;
    ScanMessageBodies[policyType] = $("checkboxID_ScanMessageBodies").checked;
    ScanMime[policyType] = $("checkboxID_ScanMime").checked;

        // Action Section Values
    uAction[policyType] = $("selectID_ThreatPrimaryAction").value;
    uSecAction[policyType] = $("selectID_ThreatSecondaryAction").value;
    szMoveFolder[policyType] = $("textboxID_MoveFolder").value;
    dwPromptButton[policyType] = 0;
    if($("checkboxID_PromptClean").checked)
    {
        dwPromptButton[policyType]+=g_PromptActionClean;
    }
    if($("checkboxID_PromptDelete").checked)
    {
        dwPromptButton[policyType]+=g_PromptActionDelete;
    }
    if($("checkboxID_PromptMove").checked)
    {
        dwPromptButton[policyType]+=g_PromptActionMove;
    }
    if($("checkboxID_PromptDeleteMail").checked)
    {
        dwPromptButton[policyType]+=g_PromptActionDeleteMail;
    }

        // Alert Section Values
    bDisplayMessage[policyType] = $("checkboxID_DisplayMessage").checked;
    bSendMailToUser[policyType] = $("checkboxID_SendMailToUser").checked;
    szCustomMessage[policyType] = $("textboxID_CustomMessage").value;
    szSendBody[policyType] = $("textboxID_SendBody").value;
    szSendCc[policyType] = $("textboxID_SendCc").value;
    szSendSubject[policyType] = $("textboxID_SendSubject").value;
    szSendTo[policyType] = $("textboxID_SendTo").value;

        // Spyware Section Values
    ApplyNVP[policyType] = $("checkboxID_ApplyNVP").checked;
    uAction_Program[policyType] = $("selectID_UnwantedPrimaryAction").value;
    uSecAction_Program[policyType] = $("selectID_UnwantedSecondaryAction").value;

        // Reports Section Values
    bLogToFile[policyType] = $("checkboxID_LogToFile").checked;
    bLimitSize[policyType] = $("checkboxID_LimitLogFileSize").checked;
    dwMaxLogSizeMB[policyType] = $("textboxID_MaxLogSizeMB").value;
    LogFileFormat[policyType] = $("selectID_LogFileFormat").selectedIndex;
    szLogFileName[policyType] = $("textboxID_LogFileName").value;
    dwLogEvent[policyType] = 0;
    if($("ID_EnableLogSettings").checked)
    {
        dwLogEvent[policyType] += g_LOG_SETTINGS;
    }

    if($("ID_EnableLogSummary").checked)
    {
        dwLogEvent[policyType] += g_LOG_SUMMARY;
    }

    if($("ID_EnableLogEncryptFails").checked)
    {
        dwLogEvent[policyType] += g_LOG_ENCRYPT_FAILS;
    }

        // Notes Section Values
    NOTES_OAScanServerDataBases[policyType] = $("checkboxID_NotesScanServerDBS").checked;
    NOTES_OAScanServerMail[policyType] = $("checkboxID_NotesScanServerMail").checked;
    NOTES_ServerMailFolder[policyType] = $("textboxID_NotesServerMailFolder").value;
    NOTES_szNotesAppsToExclude[policyType] = $("textboxID_NotesAppsToExclude").value;
}

function displayPolicyData(policyType)
{   
        // Detection Section Values
    $("checkboxID_ScanEnabled").checked = bEnabled[policyType];
    _whattoscanTabInit(policyType);

        // Advanced Section Values
    $("checkboxID_MacroHeuristics").checked = dwMacroHeuristicsLevel[policyType];
    $("checkboxID_ProgramHeuristics").checked = dwProgramHeuristicsLevel[policyType];
    $("checkboxID_ExtensionHeuristics").checked = MultipleExtensionsHeuristic[policyType];
    $("checkboxID_ScanArchives").checked = ScanArchives[policyType];
    $("checkboxID_ScanMessageBodies").checked = ScanMessageBodies[policyType];
    $("checkboxID_ScanMime").checked = ScanMime[policyType];

        // Action Section Values
    SetSelectedActions();
    $("textboxID_MoveFolder").value = szMoveFolder[policyType];    
    $("checkboxID_PromptClean").checked = (dwPromptButton[policyType] & g_PromptActionClean);
    $("checkboxID_PromptDelete").checked = (dwPromptButton[policyType] & g_PromptActionDelete);
    $("checkboxID_PromptMove").checked = (dwPromptButton[policyType] & g_PromptActionMove);
    $("checkboxID_PromptDeleteMail").checked = (dwPromptButton[policyType] & g_PromptActionDeleteMail);

        // Alert Section Values
    $("checkboxID_DisplayMessage").checked = bDisplayMessage[policyType];
    $("checkboxID_SendMailToUser").checked  = bSendMailToUser[policyType];
    $("textboxID_CustomMessage").value = szCustomMessage[policyType];
    $("textboxID_SendBody").value = szSendBody[policyType];
    $("textboxID_SendCc").value  = szSendCc[policyType];
    $("textboxID_SendSubject").value  = szSendSubject[policyType];
    $("textboxID_SendTo").value  = szSendTo[policyType];

        // Spyware Section Values
    $("checkboxID_ApplyNVP").checked = ApplyNVP[policyType];    

        // Reports Section Values
    $("checkboxID_LogToFile").checked = bLogToFile[policyType];
    $("checkboxID_LimitLogFileSize").checked = bLimitSize[policyType];
    $("ID_EnableLogSettings").checked = (dwLogEvent[policyType] & g_LOG_SETTINGS);
    $("ID_EnableLogSummary").checked = (dwLogEvent[policyType] & g_LOG_SUMMARY);
    $("ID_EnableLogEncryptFails").checked = (dwLogEvent[policyType] & g_LOG_ENCRYPT_FAILS);
    $("textboxID_MaxLogSizeMB").value = dwMaxLogSizeMB[policyType];
    $("selectID_LogFileFormat").selectedIndex = LogFileFormat[policyType];
    $("textboxID_LogFileName").value = szLogFileName[policyType];

        // Notes Section Values
    $("checkboxID_NotesScanServerDBS").checked = NOTES_OAScanServerDataBases[policyType];
    $("checkboxID_NotesScanServerMail").checked = NOTES_OAScanServerMail[policyType];
    $("textboxID_NotesServerMailFolder").value = NOTES_ServerMailFolder[policyType];
    $("textboxID_NotesAppsToExclude").value = NOTES_szNotesAppsToExclude[policyType];

    fnToggleSendMailToUserOptions();
    fnToggleApplyNVPState();
    fnEnableReportingTabUI();
    fnEnableEmailSettingsUI();
    fnScanServerMail_OnClick($("checkboxID_NotesScanServerMail").checked);
    fnScanAllServers_OnClick($("checkboxID_NotesScanServerDBS").checked);

    _doReadonly();
}

function requireSpecifiedFileTypes(require)
{
    OrionForm.setFieldRequired("textareaID_SpecifiedFileTypes", require);
}