var g_MAX_TIMEOUT_OFF         = 4294967295;   // (0xFFFFFFFF)

// For OASEnabled
var g_SCANNER_ENABLED           = 3;
var g_SCANNER_DISABLED          = 2;

// globals
var g_Wrkstn_SSExclusionsAddWidget = null;
var g_Server_SSExclusionsAddWidget = null;

var g_Wrkstn_SSURLExclusionsAddWidget = null;
var g_Server_SSURLExclusionsAddWidget = null;

var bDontScanBootSectors = new Array();
var bDontScanMBRSectors = new Array();
var bScanFloppyOnShutdown = new Array();
var ScanProcessesOnEnable = new Array();
var bWhiteListTrustedInstallers = new Array();
var ScanArchiveTimeout = new Array();
var ScannerThreadTimeout = new Array();
var ScannerThreadTimeoutEx = new Array();
var bStartDisabled = new Array();
var dwHeuristicNetCheckSensitivity = new Array();
var ScanCookies = new Array();
var OASEnabled = new Array();

// ScriptScan Section Values
var ScriptScanEnabled = new Array();

// Blocking Section Values
var VSIDSendMessage = new Array();
var VSIDMessage = new Array();
var VSIDBlock = new Array();
var VSIDBlockTimeout = new Array();
var VSIDBlockOnNonVirus = new Array();

// Messages Section Values
var bShowAlerts = new Array();
var szDialogMessage = new Array();
var bRemoveAlerts = new Array();
var bCleanFiles = new Array();
var bDeleteFiles = new Array();
var bExcludeCookies = new Array();

// Reports Section Values
var bLogToFile = new Array();
var szLogFileName = new Array();
var bLimitSize = new Array();
var dwMaxLogSizeMB = new Array();
var bLogDetection = new Array();
var bLogSettings = new Array();
var bLogClean = new Array();
var bLogSummary = new Array();
var bLogDelete = new Array();
var bLogDateTime = new Array();
var bLogMove = new Array();
var bLogScanFailure = new Array();
var bLogEncryptFails = new Array();
var LogFileFormat = new Array();

function epoApplyPolicySettings()
{
    //fnSetWFlags();
    fnSetScanTimeOut();
    //fnSetHiddenValues();

    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveOASGeneralPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function fnSetWFlags()
{
    var enableOASOnEnforce = document.getElementById("checkboxID_EnableOASOnEnforce").checked;

    if(enableOASOnEnforce)
    {
        document.getElementById("checkboxID_EnableOASOnEnforce").value = g_SCANNER_ENABLED;
    }
    else
    {
        document.getElementById("checkboxID_EnableOASOnEnforce").value = g_SCANNER_DISABLED;
    }
};

function fnSetHiddenValues()
{
    var LogFileFormatIndex = document.getElementById("selectID_LogFileFormat").selectedIndex;
    var ScanBootSectors = document.getElementById("checkboxID_DontScanBootSectors").checked;
    var ScanAtStartup = document.getElementById("checkboxID_EnableOASAtStartup").checked;

    document.getElementById("selectID_LogFileFormat").value = LogFileFormatIndex;
    document.getElementById("checkboxID_DontScanBootSectors").value = !ScanBootSectors;
    document.getElementById("checkboxID_EnableOASAtStartup").value = !ScanAtStartup;
};

function fnSetScanTimeOut()
{
    ScannerThreadTimeoutEx[0] = ScannerThreadTimeout[0];
    ScannerThreadTimeoutEx[1] = ScannerThreadTimeout[1] ;
};

// for ScriptScan URL exclusions
function Wrkstn_SSExclURLAddCallback(newDiv)
{

    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_WrkstnSSExclusionsURLList_awrow_", "");
        var ProcessElement = $("wrkstn_ss_excl_url_"+itemID);
        var hiddenValueName = "divID_WrkstnSSExclusionsURLList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            if(ProcessElement != null)
            {
                ProcessElement.value = hiddenValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById(ProcessElement.id, validatePolicy, null, "keyup", false);
            OrionForm.addFieldValidators(ProcessElement.id, [validateURLExclusion]);
        }

        validatePolicy();
    }

}

function SSExclURLRemoveCallback(newDiv)
{
    validatePolicy();
}

function Server_SSExclURLAddCallback(newDiv)
{

    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_ServerSSExclusionsURLList_awrow_", "");
        var ProcessElement = $("server_ss_excl_url_"+itemID);
        var hiddenValueName = "divID_ServerSSExclusionsURLList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            if(ProcessElement != null)
            {
                ProcessElement.value = hiddenValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById(ProcessElement.id, validatePolicy, null, "keyup", false);
            OrionForm.addFieldValidators(ProcessElement.id, [validateURLExclusion]);
        }
    }

    validatePolicy();

}
//end of required functions for ScriptScan URL exclusions

function Wrkstn_SSExclAddCallback(newDiv)
{

    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_WrkstnSSExclusionsList_awrow_", "");
        var ProcessElement = $("wrkstn_ss_excl_process_"+itemID);
        var hiddenValueName = "divID_WrkstnSSExclusionsList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            if(ProcessElement != null)
            {
                ProcessElement.value = hiddenValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById(ProcessElement.id, validatePolicy, null, "keyup", false);
            OrionForm.addFieldValidators(ProcessElement.id, [validateExclusion]);
        }

        validatePolicy();
    }
}

function Server_SSExclAddCallback(newDiv)
{

    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_ServerSSExclusionsList_awrow_", "");
        var ProcessElement = $("server_ss_excl_process_"+itemID);
        var hiddenValueName = "divID_ServerSSExclusionsList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            if(ProcessElement != null)
            {
                ProcessElement.value = hiddenValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById(ProcessElement.id, validatePolicy, null, "keyup", false);
            OrionForm.addFieldValidators(ProcessElement.id, [validateExclusion]);
        }
    }

    validatePolicy();
}

function SSExclRemoveCallback(newDiv)
{
    validatePolicy();
}

function writeSSExclusionsHiddenData()
{
    var SSExclusions = g_Wrkstn_SSExclusionsAddWidget.getList();
    var exclProcesses = "";

    for(var i=0; i < SSExclusions.length; ++i)
    {
        var currentItemID = SSExclusions[i].replace("divID_WrkstnSSExclusionsList_awrow_", "");
        var Process = $("wrkstn_ss_excl_process_"+currentItemID);

        if(Process.value != "")
        {
            exclProcesses += Process.value;

            if(i < (SSExclusions.length-1))
            {
                exclProcesses += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }
    $("hiddenID_WrkstnSSExclProcesses").value = exclProcesses;

    SSExclusions = g_Server_SSExclusionsAddWidget.getList();
    exclProcesses = "";

    for(var i=0; i < SSExclusions.length; ++i)
    {
        var currentItemID = SSExclusions[i].replace("divID_ServerSSExclusionsList_awrow_", "");
        var Process = $("server_ss_excl_process_"+currentItemID);

        if(Process.value != "")
        {
            exclProcesses += Process.value;

            if(i < (SSExclusions.length-1))
            {
                exclProcesses += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }
    $("hiddenID_ServerSSExclProcesses").value = exclProcesses;
}

function writeSSURLExclusionsHiddenData()
{
    var SSURLExclusions = g_Wrkstn_SSURLExclusionsAddWidget.getList();
    var exclURLs = "";

    for(var i=0; i < SSURLExclusions.length; ++i)
    {
        var currentItemID = SSURLExclusions[i].replace("divID_WrkstnSSExclusionsURLList_awrow_", "");
        //var Process = $("wrkstn_ss_excl_url_"+currentItemID);
        var URL = $("wrkstn_ss_excl_url_"+currentItemID);

        if(URL.value != "")
        {
            exclURLs += URL.value;

            if(i < (SSURLExclusions.length-1))
            {
                exclURLs += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    $("hiddenID_WrkstnSSExclURLs").value = exclURLs;

    SSURLExclusions = g_Server_SSURLExclusionsAddWidget.getList();
    exclURLs = "";

    for(var i=0; i < SSURLExclusions.length; ++i)
    {
        var currentItemID = SSURLExclusions[i].replace("divID_ServerSSExclusionsURLList_awrow_", "");
        var URL = $("server_ss_excl_url_"+currentItemID);

        if(URL.value != "")
        {
            exclURLs += URL.value;

            if(i < (SSURLExclusions.length-1))
            {
                exclURLs += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }
    $("hiddenID_ServerSSExclURLs").value = exclURLs;

}
function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);

    writeSSExclusionsHiddenData();
    writeSSURLExclusionsHiddenData();

    //WORKSTATION
    $("hiddenID_Wrkstn_DontScanBootSectors").value = bDontScanBootSectors[0];
    $("hiddenID_Wrkstn_DontScanMBRSectors").value = bDontScanMBRSectors[0];
    $("hiddenID_Wrkstn_FloppyShutdown").value = bScanFloppyOnShutdown[0];
    $("hiddenID_Wrkstn_ScanProcessesOnEnable").value = ScanProcessesOnEnable[0];
    $("hiddenID_Wrkstn_WhiteListTrustedInstallers").value = bWhiteListTrustedInstallers[0];
    // $("hiddenID_Wrkstn_ScanArchiveTimeout").value = ScanArchiveTimeout[0];
    $("hiddenID_Wrkstn_ScannerThreadTimeout").value = (ScannerThreadTimeout[0]);
    $("hiddenID_Wrkstn_ScannerThreadTimeoutEx").value = (ScannerThreadTimeoutEx[0]);
    $("hiddenID_Wrkstn_EnableOASAtStartup").value = bStartDisabled[0];
    $("hiddenID_Wrkstn_HeuristicSensitivity").value = dwHeuristicNetCheckSensitivity[0];
    $("hiddenID_Wrkstn_ScanCookies").value = ScanCookies[0];
    $("hiddenID_Wrkstn_EnableOASOnEnforce").value = OASEnabled[0];

    // ScriptScan Section Values
    $("hiddenID_Wrkstn_ScriptScanEnabled").value = ScriptScanEnabled[0];

    // Blocking Section Values
    $("hiddenID_Wrkstn_VSIDSendMessage").value = VSIDSendMessage[0];
    $("hiddenID_Wrkstn_VSIDMessage").value = VSIDMessage[0];
    $("hiddenID_Wrkstn_VSIDBlock").value = VSIDBlock[0];
    $("hiddenID_Wrkstn_VSIDBlockTimeout").value = VSIDBlockTimeout[0];
    $("hiddenID_Wrkstn_VSIDBlockOnNonVirus").value = VSIDBlockOnNonVirus[0];

    // Messages Section Values
    $("hiddenID_Wrkstn_ShowAlerts").value = bShowAlerts[0];
    $("hiddenID_Wrkstn_DialogMessage").value = szDialogMessage[0];
    $("hiddenID_Wrkstn_RemoveAlerts").value = bRemoveAlerts[0];
    $("hiddenID_Wrkstn_CleanFiles").value = bCleanFiles[0];
    $("hiddenID_Wrkstn_DeleteFiles").value = bDeleteFiles[0];
    $("hiddenID_Wrkstn_ExcludeCookies").value = bExcludeCookies[0];

    // Reports Section Values
    $("hiddenID_Wrkstn_LogToFile").value = bLogToFile[0];
    $("hiddenID_Wrkstn_LogFileName").value = szLogFileName[0];
    $("hiddenID_Wrkstn_LimitSize").value = bLimitSize[0];
    $("hiddenID_Wrkstn_MaxLogSizeMB").value = dwMaxLogSizeMB[0];
    $("hiddenID_Wrkstn_LogSettings").value = bLogSettings[0];
    $("hiddenID_Wrkstn_LogSummary").value = bLogSummary[0];
    $("hiddenID_Wrkstn_LogEncryptFails").value = bLogEncryptFails[0];
    $("hiddenID_Wrkstn_LogFileFormat").value = LogFileFormat[0];

    //SERVER
    $("hiddenID_Server_DontScanBootSectors").value = bDontScanBootSectors[1];
    $("hiddenID_Server_DontScanMBRSectors").value = bDontScanMBRSectors[1];
    $("hiddenID_Server_FloppyShutdown").value = bScanFloppyOnShutdown[1];
    $("hiddenID_Server_ScanProcessesOnEnable").value = ScanProcessesOnEnable[1];
    $("hiddenID_Server_WhiteListTrustedInstallers").value = bWhiteListTrustedInstallers[1];
    //$("hiddenID_Server_ScanArchiveTimeout").value = ScanArchiveTimeout[1];
    $("hiddenID_Server_ScannerThreadTimeout").value = (ScannerThreadTimeout[1]);
    $("hiddenID_Server_ScannerThreadTimeoutEx").value = (ScannerThreadTimeoutEx[1]);
    $("hiddenID_Server_EnableOASAtStartup").value = bStartDisabled[1];
    $("hiddenID_Server_HeuristicSensitivity").value = dwHeuristicNetCheckSensitivity[1];
    $("hiddenID_Server_ScanCookies").value = ScanCookies[1];
    $("hiddenID_Server_EnableOASOnEnforce").value = OASEnabled[1];

    // ScriptScan Section Values
    $("hiddenID_Server_ScriptScanEnabled").value = ScriptScanEnabled[1];

    // Blocking Section Values
    $("hiddenID_Server_VSIDSendMessage").value = VSIDSendMessage[1];
    $("hiddenID_Server_VSIDMessage").value = VSIDMessage[1];
    $("hiddenID_Server_VSIDBlock").value = VSIDBlock[1];
    $("hiddenID_Server_VSIDBlockTimeout").value = VSIDBlockTimeout[1];
    $("hiddenID_Server_VSIDBlockOnNonVirus").value = VSIDBlockOnNonVirus[1];

    // Messages Section Values
    $("hiddenID_Server_ShowAlerts").value = bShowAlerts[1];
    $("hiddenID_Server_DialogMessage").value = szDialogMessage[1];
    $("hiddenID_Server_RemoveAlerts").value = bRemoveAlerts[1];
    $("hiddenID_Server_CleanFiles").value = bCleanFiles[1];
    $("hiddenID_Server_DeleteFiles").value = bDeleteFiles[1];
    $("hiddenID_Server_ExcludeCookies").value = bExcludeCookies[1];

    // Reports Section Values
    $("hiddenID_Server_LogToFile").value = bLogToFile[1];
    $("hiddenID_Server_LogFileName").value = szLogFileName[1];
    $("hiddenID_Server_LimitSize").value = bLimitSize[1];
    $("hiddenID_Server_MaxLogSizeMB").value = dwMaxLogSizeMB[1];
    $("hiddenID_Server_LogSettings").value = bLogSettings[1];
    $("hiddenID_Server_LogSummary").value = bLogSummary[1];
    $("hiddenID_Server_LogEncryptFails").value = bLogEncryptFails[1];
    $("hiddenID_Server_LogFileFormat").value = LogFileFormat[1];
}

function storePolicyData(policyType)
{
    bDontScanBootSectors[policyType] = !($("checkboxID_DontScanBootSectors").checked);
    bDontScanMBRSectors[policyType] = !($("checkboxID_DontScanBootSectors").checked);
    bScanFloppyOnShutdown[policyType] = $("checkboxID_FloppyShutdown").checked;
    ScanProcessesOnEnable[policyType] = $("checkboxID_ScanProcessesOnEnable").checked;
    bWhiteListTrustedInstallers[policyType] = !$("checkboxID_WhiteListTrustedInstallers").checked;

    //  ScanArchiveTimeout[policyType] = $("textboxID_ScanArchiveTimeout").value;
    if($("ID_EnforceMaxScanTime").checked)
    {
        ScannerThreadTimeout[policyType] = $("textboxID_ScannerThreadTimeout").value * 1000;
        ScannerThreadTimeoutEx[policyType] = $("textboxID_ScannerThreadTimeout").value * 1000;
    }
    else
    {
        ScannerThreadTimeout[policyType] = g_MAX_TIMEOUT_OFF;
        ScannerThreadTimeoutEx[policyType] =g_MAX_TIMEOUT_OFF;
    }

    bStartDisabled[policyType] = !$("checkboxID_EnableOASAtStartup").checked;
    dwHeuristicNetCheckSensitivity[policyType] = $("selectID_HeuristicSensitivity").value;
    ScanCookies[policyType] = $("checkboxID_ScanCookies").checked;

    if($("checkboxID_EnableOASOnEnforce").checked)
    {
        OASEnabled[policyType] = g_SCANNER_ENABLED;
    }
    else
    {
        OASEnabled[policyType] = g_SCANNER_DISABLED;
    }

    // ScriptScan Section Values
    ScriptScanEnabled[policyType] = $("checkboxID_ScriptScanEnabled").checked;

    // Blocking Section Values
    VSIDSendMessage[policyType] = $("checkboxID_VSIDSendMessage").checked;
    VSIDMessage[policyType] = $("textboxID_VSIDMessage").value;
    VSIDBlock[policyType] = $("checkboxID_VSIDBlock").checked;
    VSIDBlockTimeout[policyType] = $("textboxID_VSIDBlockTimeout").value;
    VSIDBlockOnNonVirus[policyType] = $("checkboxID_VSIDBlockOnNonVirus").checked;

    // Messages Section Values
    bShowAlerts[policyType] = $("checkboxID_ShowAlerts").checked;
    szDialogMessage[policyType] = $("textboxID_DialogMessage").value;
    bRemoveAlerts[policyType] = $("checkboxID_RemoveAlerts").checked;
    bCleanFiles[policyType] = $("checkboxID_CleanFiles").checked;
    bDeleteFiles[policyType] = $("checkboxID_DeleteFiles").checked;
    bExcludeCookies[policyType] = !($("checkboxID_ExcludeCookies").checked);

    // Reports Section Values
    bLogToFile[policyType] = $("checkboxID_LogToFile").checked;
    szLogFileName[policyType] = $("textboxID_LogFileName").value;
    bLimitSize[policyType] = $("checkboxID_LimitLogFileSize").checked;
    dwMaxLogSizeMB[policyType] = $("textboxID_MaxLogSizeMB").value;
    bLogSettings[policyType] = $("checkboxID_LogSettings").checked;
    bLogSummary[policyType] = $("checkboxID_LogSummary").checked;
    bLogEncryptFails[policyType] = $("checkboxID_LogEncryptFails").checked;
    LogFileFormat[policyType] = $("selectID_LogFileFormat").value;
}

function displayPolicyData(policyType)
{
    $("checkboxID_DontScanBootSectors").checked = !bDontScanBootSectors[policyType];
    //$("checkboxID_DontScanMBRSectors").checked = bDontScanMBRSectors[policyType];
    $("checkboxID_FloppyShutdown").checked = bScanFloppyOnShutdown[policyType];
    $("checkboxID_ScanProcessesOnEnable").checked = ScanProcessesOnEnable[policyType];
    $("checkboxID_WhiteListTrustedInstallers").checked = !bWhiteListTrustedInstallers[policyType];

    //$("textboxID_ScanArchiveTimeout").value = ScanArchiveTimeout[policyType];

    fnDisplayGeneralTab();

    //$("checkboxID_").checked = ScannerThreadTimeoutEx[policyType];
    $("checkboxID_EnableOASAtStartup").checked = !bStartDisabled[policyType];
    $("selectID_HeuristicSensitivity").value = dwHeuristicNetCheckSensitivity[policyType];
    $("checkboxID_ScanCookies").checked = ScanCookies[policyType];
    $("checkboxID_EnableOASOnEnforce").checked = (OASEnabled[policyType] == g_SCANNER_ENABLED);

    // ScriptScan Section Values
    $("checkboxID_ScriptScanEnabled").checked = ScriptScanEnabled[policyType];
    fnSetScriptScanEnabledState();

    // Blocking Section Values
    $("checkboxID_VSIDSendMessage").checked = VSIDSendMessage[policyType];
    $("textboxID_VSIDMessage").value = VSIDMessage[policyType];
    $("checkboxID_VSIDBlock").checked = VSIDBlock[policyType];
    $("textboxID_VSIDBlockTimeout").value = VSIDBlockTimeout[policyType];
    $("checkboxID_VSIDBlockOnNonVirus").checked = VSIDBlockOnNonVirus[policyType];

    // Messages Section Values
    $("checkboxID_ShowAlerts").checked = bShowAlerts[policyType];
    $("textboxID_DialogMessage").value = szDialogMessage[policyType];
    $("checkboxID_RemoveAlerts").checked = bRemoveAlerts[policyType];
    $("checkboxID_CleanFiles").checked = bCleanFiles[policyType];
    $("checkboxID_DeleteFiles").checked = bDeleteFiles[policyType];
    $("checkboxID_ExcludeCookies").checked = !(bExcludeCookies[policyType]);

    // Reports Section Values
    $("checkboxID_LogToFile").checked = bLogToFile[policyType];
    $("textboxID_LogFileName").value = szLogFileName[policyType];
    $("checkboxID_LimitLogFileSize").checked = bLimitSize[policyType];
    $("textboxID_MaxLogSizeMB").value = dwMaxLogSizeMB[policyType];
    $("checkboxID_LogSettings").checked = bLogSettings[policyType];
    $("checkboxID_LogSummary").checked = bLogSummary[policyType];
    $("checkboxID_LogEncryptFails").checked = bLogEncryptFails[policyType];
    $("selectID_LogFileFormat").value = LogFileFormat[policyType];

    fnSetReportFormat();
    displayExclusionsLists(policyType);
    enableBlockMessageUI($("checkboxID_VSIDSendMessage").checked);
    fnEnableReportingTabUI();
    fnEnableMessageTabUI();

    _doReadonly();
}
/*function validateArchiveTimeout(szArchiveTimeout)
 {
 var valid = true;
 $("spanID_ScanArchiveTimeout_error").style.display = "none";

 if(szArchiveTimeout == null || szArchiveTimeout == "")
 {
 valid = false;
 }

 var archiveTimeout = parseInt(szArchiveTimeout);

 if(valid)
 {
 valid = !(archiveTimeout < 5 || archiveTimeout > 999);
 }

 if(valid)
 {

 if($("ID_EnforceMaxScanTime").checked)
 {
 var maxScanTime = $("textboxID_ScannerThreadTimeout").value;
 if(maxScanTime == null || maxScanTime == "" || (archiveTimeout >= parseInt(maxScanTime)))
 {
 $("spanID_ScanArchiveTimeout_error").style.display = "";
 valid = false;
 }
 }
 }

 return valid;
 }*/

function validateMaxScanTime(szMaxScanTime)
{
    var valid = true;

    if($("ID_EnforceMaxScanTime").checked == false)
    {
        return true;
    }

    if(szMaxScanTime == null || szMaxScanTime == "")
    {
        valid = false;
    }

    if(valid)
    {
        var maxScanTime = parseInt(szMaxScanTime);
        valid =  !(maxScanTime < 10 || maxScanTime > 9999);
    }

    return valid;
}

function validateVSIDMessage(szMessage)
{
    if(szMessage == null || szMessage == "")
    {
        return true;
    }

    return IsValidMacro(szMessage);
}

function validateBlockTimeout(szTimeout)
{
    var valid = true;

    if($("checkboxID_VSIDBlock").checked)
    {
        valid = (szTimeout > 0 && szTimeout < 10000);
    }

    return valid;
}

function validateExclusion(szExclusion)
{
    var r;

    r = szExclusion.indexOf("/");

    if(r == -1)
        r = szExclusion.indexOf("\\");

    if(r == -1)
        r = szExclusion.indexOf("\*");

    if(r == -1)
        r = szExclusion.indexOf("?");

    if(r == -1)
        r = szExclusion.indexOf("\"");

    if(r == -1)
        r = szExclusion.indexOf("|");

    if(r == -1)
        r = szExclusion.indexOf("<");

    if(r == -1)
        r = szExclusion.indexOf(">");

    if(r == -1)
        r = szExclusion.indexOf(":");

    if(r == -1)
        return true;

    return false;
}

//probably need a validation function for URL exclusion
function validateURLExclusion(szExclusion)
{
    // var regexpWithHttpCheck = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;


    /* if (regexpWithHttpCheck.test(szExclusion))return true;
     return false;      */
    var r;

    // alert('test');
    r = szExclusion.indexOf("*");

    if(r == -1)
        r = szExclusion.indexOf("?");

    if(r == -1)
        return true;

    return false;

}
