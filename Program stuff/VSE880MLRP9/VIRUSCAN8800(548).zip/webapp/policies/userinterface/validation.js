function validateFQDN(dns){
    var isValid = (OrionValidate.isValidHostName(dns) && !OrionValidate.isValidIPString(dns));
    return isValid;
}