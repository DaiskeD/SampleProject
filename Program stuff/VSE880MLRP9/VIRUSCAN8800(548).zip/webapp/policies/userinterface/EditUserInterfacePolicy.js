// globals
var g_OAS_PasswordItems = new Array();
var g_ODS_SavedTasks_PasswordItems = new Array();
var g_ODS_UnsavedTasks_PasswordItems = new Array();
var g_Email_OnDelivery_PasswordItems = new Array();
var g_Email_OnDemand_PasswordItems = new Array();
var g_AP_PasswordItems = new Array();
var g_BOP_PasswordItems = new Array();
var g_UnwantedProgs_PasswordItems = new Array();
var g_AutoUpdate_PasswordItems = new Array();
var g_Other_PasswordItems = new Array();
var DisablePersistentCache = new Array();
var bODSUseCache = new Array();

var bArtemisLookupEnable = new Array();
var ArtemisServerDomainName = new Array();

var g_LockStates = new Array();
g_LockStates[0] = new Array();
g_LockStates[1] = new Array();

// Workstation/Server Data
var bAllowRemote = new Array();
var bDisableDefaultTask = new Array();
var bDisplayEpoTasks = new Array();
var bEnableTalkback = new Array();
var bSkipSplash = new Array();
var dwUIMode = new Array();
var UIP = new Array();
var UIPEx = new Array();
var UIPMode = new Array();
var UIPPages = new Array();
var szPreferredLanguage = new Array();
var bEnableLogging = new Array();
var sLogLevel = new Array();

// constants
var PWITEM_START = -1;
var PWITEM_STOP = -2;

// The order of enumeration is from UIPasswordItems.h
{
	var PWITEM_CONSOLE                 =  0; ///< Console and Shield menu (this is a "catch-all" that includes disabling/enabling OAS, disabling/enabling On-Delivery E-mail Scan, creating/deleting/renaming tasks, stopping scheduled tasks, changing the password, changing the default task settings, etc.).

    var PWITEM_OAS_GENERAL             =  1; ///< On-Access Scan: General
    var PWITEM_OAS_MESSAGES            =  2; ///< On-Access Scan: Messages
    var PWITEM_OAS_REPORTS             =  3; ///< On-Access Scan: Reports
    var PWITEM_OAS_PROCESSES           =  4; ///< On-Access Scan: Processes *
    var PWITEM_OAS_DETECTION           =  5; ///< On-Access Scan: Detection *
    var PWITEM_OAS_EXCLUSIONS          =  6; ///< On-Access Scan: Exclusions (button on the Detection tab) *
    var PWITEM_OAS_ADVANCED            =  7; ///< On-Access Scan: Advanced *
    var PWITEM_OAS_ACTION              =  8; ///< On-Access Scan: Action *

    // Saved (ie. console tasks)
    var PWITEM_SODS_WHERE              =  9; ///< On-Demand Scan: Where **
    var PWITEM_SODS_DETECTION          = 10; ///< On-Demand Scan: Detection
    var PWITEM_SODS_EXCLUSIONS         = 11; ///< On-Demand Scan: Exclusions (button on the Detection tab)
    var PWITEM_SODS_ADVANCED           = 12; ///< On-Demand Scan: Advanced
    var PWITEM_SODS_ACTION             = 13; ///< On-Demand Scan: Actions
    var PWITEM_SODS_REPORTS            = 14; ///< On-Demand Scan: Reports
    var PWITEM_SODS_SCHEDULE           = 15; ///< On-Demand Scan: Schedule (button in the main window)

    // unsaved (ie. temporary tasks)
    var PWITEM_UODS_WHERE              = 16; ///< On-Demand Scan: Where **
    var PWITEM_UODS_DETECTION          = 17; ///< On-Demand Scan: Detection
    var PWITEM_UODS_EXCLUSIONS         = 18; ///< On-Demand Scan: Exclusions (button on the Detection tab)
    var PWITEM_UODS_ADVANCED           = 19; ///< On-Demand Scan: Advanced
    var PWITEM_UODS_ACTION             = 20; ///< On-Demand Scan: Actions
    var PWITEM_UODS_REPORTS            = 21; ///< On-Demand Scan: Reports
    var PWITEM_UODS_SCHEDULE           = 22; ///< On-Demand Scan: Schedule (button in the main window)

    var PWITEM_DEL_EMAIL_DETECTION     = 23; ///< E-mail Scan: Detection ***
    var PWITEM_DEL_EMAIL_ADVANCED      = 24; ///< E-mail Scan: Advanced
    var PWITEM_DEL_EMAIL_ACTION        = 25; ///< E-mail Scan: Actions
    var PWITEM_DEL_EMAIL_ALERTS        = 26; ///< E-mail Scan: Alerts
    var PWITEM_DEL_EMAIL_REPORTS       = 27; ///< E-mail Scan: Reports

    var PWITEM_DEM_EMAIL_DETECTION     = 28; ///< E-mail Scan: Detection ***
    var PWITEM_DEM_EMAIL_ADVANCED      = 29; ///< E-mail Scan: Advanced
    var PWITEM_DEM_EMAIL_ACTION        = 30; ///< E-mail Scan: Actions
    var PWITEM_DEM_EMAIL_ALERTS        = 31; ///< E-mail Scan: Alerts
    var PWITEM_DEM_EMAIL_REPORTS       = 32; ///< E-mail Scan: Reports

    var PWITEM_AUTOUPDATE              = 33; ///< AutoUpdate

	var PWITEM_AMGCLIENT               = 34; ///< Alert Manager Client

    // Do NOT re-order, add, or remove items above this line -- fixed in stone at VSE 7.1

    var PWITEM_SCRIPTSCANCONFIG        = 35; ///< Scriptscan

    var PWITEM_OAS_SPYWARE             = 36; ///< Spyware in OAS
    var PWITEM_SODS_SPYWARE            = 37; ///< Spyware in ODS
    var PWITEM_UODS_SPYWARE            = 38; ///< Spyware in ODS
    var PWITEM_DEL_EMAIL_SPYWARE       = 39; ///< Spyware in E-mail On-delivery Scan
    var PWITEM_DEM_EMAIL_SPYWARE       = 40; ///< Spyware in E-mail On-demand Scan

    var PWITEM_BB_ACCESS_PROTECTION    = 41; ///< Behavior blocking: Firewall
    var PWITEM_BB_ENTERCEPT            = 42; ///< Behavior blocking: Entercept
    var PWITEM_BB_VSID                 = 44; ///< Behavior blocking: VSID page
    var PWITEM_BB_LOGGING              = 45; ///< Behavior blocking: Logging page
    var PWITEM_BB_LOGGING_ENT          = 46; ///< Behavior blocking: Logging page for Entercept

    var PWITEM_NVPOLICY_DET            = 47; ///< Unwanted Programs Policy: Detection
    var PWITEM_NVPOLICY_USR_DEF        = 48; ///< Unwanted Programs Policy: User-Defined Detection

    var PWITEM_REPAIR				   = 49; ///< Unwanted Programs Policy: User-Defined Detection

    var PWITEM_DEL_EMAIL_NOTES		   = 50; // Email Notes Page
	var PWITEM_DEM_EMAIL_NOTES		   = 51; // Email Notes Page
    var PWITEM_QUARPOLICY_CONFIG       = 52; // Quarantine policy configuration page
    var PWITEM_QUARPOLICY_MANAGER      = 53; // Quarantine policy manager page
    var PWITEM_END                     = 54; ///< End marker for this enum
}

function epoApplyPolicySettings()
{
    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveUserInterfacePolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function encodePassword()
{
    var encodedPasswordInput = $("hiddenID_encodedPassword");

    if(UIP[0] != "")
    {
        $("hiddenID_WrkstnUIP").value = parent.PolicyCore.legacyEncodeString(UIP[0]);
    }
    else
    {
        $("hiddenID_WrkstnUIP").value = "";
    }

    if(UIP[1] != "")
    {
        $("hiddenID_ServerUIP").value = parent.PolicyCore.legacyEncodeString(UIP[1]);
    }
    else
    {
        $("hiddenID_ServerUIP").value = "";        
    }
}

function storePasswordLockString(policyType)
{
    var szLockString = "";

    for (var i = 0; i < g_LockStates[policyType].length; i++)
    {
        if ( g_LockStates[policyType][i] )
        {
            szLockString += "1";
        }
        else
        {
            szLockString += "0";
        }
    }
    UIPPages[policyType] = szLockString;
}

function validatePassword()
{
    var valid = true;

    if($("radioID_NoPassword").checked)
    {
        return true;
    }

    if($("textboxID_Password").value != $("textboxID_ConfirmPassword").value)
    {
        valid = false;
    }

    if($("textboxID_Password").value == "")
    {
        valid = false;
    }

    return valid;
}

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    $("hiddenID_WrkstnUIMode").value = dwUIMode[0];
    $("hiddenID_WrkstnAllowRemote").value = bAllowRemote[0];
    $("hiddenID_WrkstnDisplayEpoTasks").value = bDisplayEpoTasks[0];
    $("hiddenID_WrkstnDisableDefaultTask").value = bDisableDefaultTask[0];
    $("hiddenID_WrkstnSkipSplash").value = bSkipSplash[0];
    $("hiddenID_WrkstnUIPMode").value = UIPMode[0];
    $("hiddenID_WrkstnUIPPages").value = UIPPages[0];
    $("hiddenID_WrkstnUIP").value = UIP[0];
    $("hiddenID_WrkstnUIPEx").value = UIPEx[0];
    $("hiddenID_WrkstnPreferredLanguage").value = szPreferredLanguage[0];
    $("hiddenID_Wrkstn_DisablePersistentCache").value = DisablePersistentCache[0];
    $("hiddenID_Wrkstn_ODSUseCache").value = bODSUseCache[0];
    if(bArtemisLookupEnable[0] == "false"){
        if(ArtemisServerDomainName[0] != ""){
            $("hiddenID_Wrkstn_ArtemisLookupEnable").value = false;
            $("hiddenID_Wrkstn_ArtemisServerDomainName").value = ArtemisServerDomainName[0];
        }
        else{
            $("hiddenID_Wrkstn_ArtemisLookupEnable").value = true;
            $("hiddenID_Wrkstn_ArtemisServerDomainName").value = "avqs.mcafee.com";
        }
    }
    else {
        $("hiddenID_Wrkstn_ArtemisLookupEnable").value = bArtemisLookupEnable[0];
        $("hiddenID_Wrkstn_ArtemisServerDomainName").value = ArtemisServerDomainName[0];
    }
    $("hiddenID_Wrkstn_bEnableLogging").value = bEnableLogging[0];
    $("hiddenID_Wrkstn_dwLogLevel").value = sLogLevel[0];


    $("hiddenID_ServerUIMode").value = dwUIMode[1];
    $("hiddenID_ServerAllowRemote").value = bAllowRemote[1];
    $("hiddenID_ServerDisplayEpoTasks").value = bDisplayEpoTasks[1];
    $("hiddenID_ServerDisableDefaultTask").value = bDisableDefaultTask[1];
    $("hiddenID_ServerSkipSplash").value = bSkipSplash[1];
    $("hiddenID_ServerUIPMode").value = UIPMode[1];
    $("hiddenID_ServerUIPPages").value = UIPPages[1];
    $("hiddenID_ServerUIP").value = UIP[1];
    $("hiddenID_ServerUIPEx").value = UIPEx[1];
    $("hiddenID_ServerPreferredLanguage").value = szPreferredLanguage[1];
    $("hiddenID_Server_DisablePersistentCache").value = DisablePersistentCache[1];
    $("hiddenID_Server_ODSUseCache").value = bODSUseCache[1];
    if(bArtemisLookupEnable[1] == "false"){
        if(ArtemisServerDomainName[1] != ""){
            $("hiddenID_Server_ArtemisLookupEnable").value = false;
            $("hiddenID_Server_ArtemisServerDomainName").value = ArtemisServerDomainName[1];
        }
        else{
            $("hiddenID_Server_ArtemisLookupEnable").value = true;
            $("hiddenID_Server_ArtemisServerDomainName").value = "avqs.mcafee.com";
        }
    }
    else {
        $("hiddenID_Server_ArtemisLookupEnable").value = bArtemisLookupEnable[1];
        $("hiddenID_Server_ArtemisServerDomainName").value = ArtemisServerDomainName[1];
    }
    $("hiddenID_Server_bEnableLogging").value = bEnableLogging[1];
    $("hiddenID_Server_dwLogLevel").value = sLogLevel[1];
}

function storePolicyData(policyType)
{
    // Store Options Tab Data
    if($("radioID_ShowAllMenuOptions").checked)
    {
        dwUIMode[policyType] = 0;
    }
    else if($("radioID_ShowMinimalMenuOptions").checked)
    {
        dwUIMode[policyType] = 1;
    }
    else
    {
        dwUIMode[policyType] = 2;
    }
    
    bAllowRemote[policyType] = $("checkboxID_AllowRemote").checked;
    bDisplayEpoTasks[policyType] = $("checkboxID_DisplayEpoTasks").checked;
    bDisableDefaultTask[policyType] = $("checkboxID_DisableDefaultTask").checked;
    bSkipSplash[policyType] = !($("checkboxID_ShowSplash").checked);
    szPreferredLanguage[policyType] = $("selectID_PreferredLanguage").value;
    DisablePersistentCache[policyType]= !($("checkboxID_DisablePersistentCache").checked);
    bODSUseCache[policyType]= ($("checkboxID_ODSUseCache").checked);
    var ArtemisLookup = $("checkboxID_ArtemisServerDomainName").checked;
    var ArtemisDNS = $("textboxID_ArtemisServerDomainName").value;
    if((!ArtemisLookup || ArtemisLookup == "false") && ArtemisDNS == ""){
        ArtemisDNS = ArtemisServerDomainName[policyType];
    }
    bArtemisLookupEnable[policyType] = $("checkboxID_ArtemisServerDomainName").checked;
    ArtemisServerDomainName[policyType] = ArtemisDNS;

    // Store Password Options Tab Data
    storePasswordLockString(policyType);
    if($("radioID_NoPassword").checked)
    {
        UIP[policyType] = "";
        UIPEx[policyType] = "";
    }
    else
    {
    	if($("textboxID_Password").value != ""
           && $("textboxID_Password").value != UIPEx[policyType]
           && $("textboxID_Password").value != UIP[policyType])
    	{        	
            UIPEx[policyType] = $("textboxID_Password").value;
        }
    }

    if($("radioID_NoPassword").checked)
    {
        UIPMode[policyType] = 0;
    }
    else if($("radioID_AllPassword").checked)
    {
        UIPMode[policyType] = 1;
    }
    else if($("radioID_CustomPassword").checked)
    {
        UIPMode[policyType] = 2;
    }
    else
    {
        UIPMode[policyType] = 3;
    }
    bEnableLogging[policyType] = $("checkboxID_Enablelogging").checked;
    sLogLevel[policyType] = $("selectID_LogLevel").value;

}

function displayPolicyData(policyType)
{
    $("radioID_ShowAllMenuOptions").checked = (dwUIMode[policyType] == 0);
    $("radioID_ShowMinimalMenuOptions").checked = (dwUIMode[policyType] == 1);
    $("radioID_HideTrayIcon").checked = (dwUIMode[policyType] == 2);

    $("checkboxID_AllowRemote").checked = bAllowRemote[policyType];
    $("checkboxID_DisplayEpoTasks").checked = bDisplayEpoTasks[policyType];
    $("checkboxID_DisableDefaultTask").checked = bDisableDefaultTask[policyType];
    $("checkboxID_ShowSplash").checked = !bSkipSplash[policyType];

    $("checkboxID_DisablePersistentCache").checked = !DisablePersistentCache[policyType];
    $("checkboxID_ODSUseCache").checked = bODSUseCache[policyType];

    $("checkboxID_Enablelogging").checked = bEnableLogging[policyType];

    var artemisDNS = ArtemisServerDomainName[policyType];
    var bArtemisEnable = bArtemisLookupEnable[policyType];
    if(bArtemisEnable == "false"){
        if(artemisDNS != ""){
            $("checkboxID_ArtemisServerDomainName").checked = false;
            $("textboxID_ArtemisServerDomainName").value = artemisDNS;
            $("textboxID_ArtemisServerDomainName").disabled = true;
        }
        else{
            $("checkboxID_ArtemisServerDomainName").checked = true;
            $("textboxID_ArtemisServerDomainName").value = "avqs.mcafee.com";
        }
    }
    else {
        $("checkboxID_ArtemisServerDomainName").checked = bArtemisLookupEnable[policyType];
        $("textboxID_ArtemisServerDomainName").value = ArtemisServerDomainName[policyType];
    }


    fnSetLanguageSelection();
    fnSetLogLevel();
    EnableLogging();
    // Display Password Tab Items
    var password = UIPEx[policyType];
    if(password != "")
    {
        $("textboxID_Password").value = password;
        $("textboxID_ConfirmPassword").value = $("textboxID_Password").value;
    }
    else
    {
        password = UIP[policyType];

        if(password != "")
        {
            $("textboxID_Password").value = password;
            $("textboxID_ConfirmPassword").value = $("textboxID_Password").value;
        }
        else
        {
            $("textboxID_Password").value = "";
            $("textboxID_ConfirmPassword").value = "";
        }
    }

    $("radioID_NoPassword").checked = (UIPMode[policyType] == 0);
    $("radioID_AllPassword").checked = (UIPMode[policyType] == 1);
    $("radioID_CustomPassword").checked = (UIPMode[policyType] == 2);
    $("radioID_CCPassword").checked = (UIPMode[policyType] == 3);

    displayPasswordUIOptions();

    _doReadonly();
}
