// globals
var g_WrkstnBOPExclusionsAddWidget = null;
var g_ServerBOPExclusionsAddWidget = null;

// BOP Data
var EnterceptEnabled = new Array();
var EnterceptMode = new Array();
var EnterceptShowMessages = new Array();

// Reports Data
var bLogToFile = new Array();
var szLogFileName = new Array();
var bLimitSize = new Array();
var dwMaxLogSizeMB = new Array();
var logFileFormat = new Array();

// constants
var WARNING_MODE = 0;
var BLOCKING_MODE = 1;

function epoApplyPolicySettings()
{
    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveBufferOverflowPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    
    Wrkstn_WriteBOPExclusions();
    Server_WriteBOPExclusions();

    $("hiddenID_WrkstnEnterceptEnabled").value = EnterceptEnabled[0];
    $("hiddenID_WrkstnEnterceptMode").value = EnterceptMode[0];
    $("hiddenID_WrkstnEnterceptShowMessages").value = EnterceptShowMessages[0];
    $("hiddenID_WrkstnLogToFile").value = bLogToFile[0];
    $("hiddenID_WrkstnLogFileName").value = szLogFileName[0];
    $("hiddenID_WrkstnLimitLogSize").value = bLimitSize[0];
    $("hiddenID_WrkstnMaxLogSize").value = dwMaxLogSizeMB[0];
    $("hiddenID_WrkstnLogFileFormat").value = logFileFormat[0];

    $("hiddenID_ServerEnterceptEnabled").value = EnterceptEnabled[1];
    $("hiddenID_ServerEnterceptMode").value = EnterceptMode[1];
    $("hiddenID_ServerEnterceptShowMessages").value = EnterceptShowMessages[1];
    $("hiddenID_ServerLogToFile").value = bLogToFile[1];
    $("hiddenID_ServerLogFileName").value = szLogFileName[1];
    $("hiddenID_ServerLimitLogSize").value = bLimitSize[1];
    $("hiddenID_ServerMaxLogSize").value = dwMaxLogSizeMB[1];
    $("hiddenID_ServerLogFileFormat").value = logFileFormat[1];
}

function Wrkstn_WriteBOPExclusions()
{
    var BOPExclusions = g_WrkstnBOPExclusionsAddWidget.getList();
    var exclProcesses = "";
    var exclModules = "";
    var exclAPIs = "";

    for(var i=0; i < BOPExclusions.length; ++i)
    {
        var currentItemID = BOPExclusions[i].replace("divID_WrkstnBOPExclusionsList_awrow_", "");
        var Process = $("wrkstn_bop_excl_process_"+currentItemID);
        var Module = $("wrkstn_bop_excl_module_"+currentItemID);
        var API = $("wrkstn_bop_excl_API_"+currentItemID);

        if(Process.value != "")
        {
            exclProcesses += Process.value;
            var APIValue = " ";
            if(Module.value != "")
            {
                APIValue = Module.value;
            }
            else if (API.value != "" )
            {
                APIValue = "*";
            }

            if(API.value != "")
            {
                APIValue += "." + API.value;
            }

            exclAPIs += APIValue;

            if(i < (BOPExclusions.length-1))
            {
                exclProcesses += Constants.LIST_TOKEN_SPLITTER;
                exclAPIs += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    $("hiddenID_WrkstnEntExclProcesses").value = exclProcesses;
    $("hiddenID_WrkstnEntExclAPIs").value = exclAPIs;
}

function Server_WriteBOPExclusions()
{
    var BOPExclusions = g_ServerBOPExclusionsAddWidget.getList();
    var exclProcesses = "";
    var exclModules = "";
    var exclAPIs = "";

    for(var i=0; i < BOPExclusions.length; ++i)
    {
        var currentItemID = BOPExclusions[i].replace("divID_ServerBOPExclusionsList_awrow_", "");
        var Process = $("server_bop_excl_process_"+currentItemID);
        var Module = $("server_bop_excl_module_"+currentItemID);
        var API = $("server_bop_excl_API_"+currentItemID);

        if(Process.value != "")
        {
            exclProcesses += Process.value;
            var APIValue = " ";
            if(Module.value != "")
            {
                APIValue = Module.value;
            }
            else if (API.value != "" )
            {
                APIValue = "*";
            }

            if(API.value != "")
            {
                APIValue += "." + API.value;
            }

            exclAPIs += APIValue;

            if(i < (BOPExclusions.length-1))
            {
                exclProcesses += Constants.LIST_TOKEN_SPLITTER;
                exclAPIs += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    $("hiddenID_ServerEntExclProcesses").value = exclProcesses;
    $("hiddenID_ServerEntExclAPIs").value = exclAPIs;
}
// ****************************************************************************
// This callback is called whenever a BOP row is added to the adder control
// ****************************************************************************
function Wrkstn_BOPExclAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_WrkstnBOPExclusionsList_awrow_", "");
        var ProcessElement = $("wrkstn_bop_excl_process_"+itemID);
        var ModuleElement = $("wrkstn_bop_excl_module_"+itemID);
        var APIElement = $("wrkstn_bop_excl_API_"+itemID);
        var hiddenValueName = "divID_WrkstnBOPExclusionsList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            var exclusionValues = hiddenValue.split(Constants.LIST_TOKEN_SPLITTER);
            if(exclusionValues.length > 0)
            {
                var CombinedValue = exclusionValues[1];
                var ModuleValue = "";
                var APIValue = "";
                if(CombinedValue != "" && CombinedValue != " ")
                {
                    var ModuleAndAPI = CombinedValue.split(".");
                    if(ModuleAndAPI.length > 0)
                    {
                        ModuleValue = ModuleAndAPI[0];
                        APIValue = ModuleAndAPI[1];

                        if(ModuleValue == "*")
                        {
                            ModuleValue = "";
                        }

                        if(APIValue == "*")
                        {
                            APIValue = "";
                        }
                    }
                }

                ProcessElement.value = exclusionValues[0];

                ModuleElement.value = ModuleValue;
                APIElement.value = APIValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById("wrkstn_bop_excl_process_" + itemID, validatePolicy, null, "keyup", false);

            // If the process element contains a value, then the API value is required.
            if(ProcessElement.value != "")
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_API_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_API_"+itemID, false);
            }
        }

        if(ModuleElement != null)
        {
            OrionEvent.registerHandlerById("wrkstn_bop_excl_module_" + itemID, function() {moduleNameChange("wrkstn_bop_excl_module_" + itemID, "wrkstn_bop_excl_API_" + itemID, "wrkstn_bop_excl_process_"+itemID);}, null, "keyup", false);
            OrionEvent.registerHandlerById("wrkstn_bop_excl_module_" + itemID, validatePolicy, null, "keyup", false);

            // If the module element contains a value, then the Process and API values are required.
            if(ModuleElement.value != "" && ModuleElement.value != " ")
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_process_"+itemID, true);
                OrionForm.setFieldRequired("wrkstn_bop_excl_API_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_process_"+itemID, false);
                OrionForm.setFieldRequired("wrkstn_bop_excl_API_"+itemID, false);
            }
        }

        if(APIElement != null)
        {
            OrionEvent.registerHandlerById("wrkstn_bop_excl_API_" + itemID, function() {APINameChange("wrkstn_bop_excl_API_" + itemID, "wrkstn_bop_excl_process_"+itemID, "wrkstn_bop_excl_module_" + itemID);}, null, "keyup", false);
            OrionEvent.registerHandlerById("wrkstn_bop_excl_API_" + itemID, validatePolicy, null, "keyup", false);

            // If the API element contains a value, then the Process value is required.
            if(APIElement.value != "" && APIElement.value != " ")
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_process_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("wrkstn_bop_excl_process_"+itemID, false);
            }
        }
    }

    fnSetAdvancedState( );
}

function Server_BOPExclAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_ServerBOPExclusionsList_awrow_", "");
        var ProcessElement = $("server_bop_excl_process_"+itemID);
        var ModuleElement = $("server_bop_excl_module_"+itemID);
        var APIElement = $("server_bop_excl_API_"+itemID);
        var hiddenValueName = "divID_ServerBOPExclusionsList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue !="")
        {
            var exclusionValues = hiddenValue.split(Constants.LIST_TOKEN_SPLITTER);
            if(exclusionValues.length > 0)
            {
                var CombinedValue = exclusionValues[1];
                var ModuleValue = "";
                var APIValue = "";
                if(CombinedValue != "" && CombinedValue != " ")
                {
                    var ModuleAndAPI = CombinedValue.split(".");
                    if(ModuleAndAPI.length > 0)
                    {
                        ModuleValue = ModuleAndAPI[0];
                        APIValue = ModuleAndAPI[1];

                        if(ModuleValue == "*")
                        {
                            ModuleValue = "";
                        }

                        if(APIValue == "*")
                        {
                            APIValue = "";
                        }
                    }
                }

                ProcessElement.value = exclusionValues[0];

                ModuleElement.value = ModuleValue;
                APIElement.value = APIValue;
            }
        }

        // Add Event Handlers
        if(ProcessElement != null)
        {
            OrionEvent.registerHandlerById("server_bop_excl_process_" + itemID, validatePolicy, null, "keyup", false);

            // If the process element contains a value, then the API value is required.
            if(ProcessElement.value != "")
            {
                OrionForm.setFieldRequired("server_bop_excl_API_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("server_bop_excl_API_"+itemID, false);
            }
        }

        if(ModuleElement != null)
        {
            OrionEvent.registerHandlerById("server_bop_excl_module_" + itemID, function() {moduleNameChange("server_bop_excl_module_" + itemID, "server_bop_excl_API_" + itemID, "server_bop_excl_process_"+itemID);}, null, "keyup", false);
            OrionEvent.registerHandlerById("server_bop_excl_module_" + itemID, validatePolicy, null, "keyup", false);

            // If the module element contains a value, then the Process and API values are required.
            if(ModuleElement.value != "" && ModuleElement.value != " ")
            {
                OrionForm.setFieldRequired("server_bop_excl_process_"+itemID, true);
                OrionForm.setFieldRequired("server_bop_excl_API_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("server_bop_excl_process_"+itemID, false);
                OrionForm.setFieldRequired("server_bop_excl_API_"+itemID, false);
            }
        }

        if(APIElement != null)
        {
            OrionEvent.registerHandlerById("server_bop_excl_API_" + itemID, function() {APINameChange("server_bop_excl_API_" + itemID, "server_bop_excl_process_"+itemID, "server_bop_excl_module_" + itemID);}, null, "keyup", false);
            OrionEvent.registerHandlerById("server_bop_excl_API_" + itemID, validatePolicy, null, "keyup", false);

            // If the API element contains a value, then the Process value is required.
            if(APIElement.value != "" && APIElement.value != " ")
            {
                OrionForm.setFieldRequired("server_bop_excl_process_"+itemID, true);
            }
            else
            {
                OrionForm.setFieldRequired("server_bop_excl_process_"+itemID, false);
            }

        }
    }

    fnSetAdvancedState( );
}

function BOPExclRemoveCallback(newDiv)
{
    validatePolicy();
}

// *****************************************************************
// Called whenever the module name value is changed.
// *****************************************************************
function moduleNameChange(szModuleElementID, szAPIElementID, processElementID)
{
    var moduleElement = $(szModuleElementID);

    if(moduleElement != null && moduleElement.value != "")
    {
        OrionForm.setFieldRequired(processElementID, true);
        OrionForm.setFieldRequired(szAPIElementID, true);
    }
    else
    {
        OrionForm.setFieldRequired(processElementID, false);
        OrionForm.setFieldRequired(szAPIElementID, false);
    }
}

// *****************************************************************
// Called whenever the API name value is changed.
// *****************************************************************
function APINameChange(szAPIElementID, processElementID, moduleElementID)
{
    var APIElement = $(szAPIElementID);

    if(APIElement != null && APIElement.value != "" && APIElement.value != " ")
    {
        OrionForm.setFieldRequired(processElementID, true);
    }
    else
    {
        OrionForm.setFieldRequired(processElementID, false);
    }        
}

function storePolicyData(policyType)
{
    EnterceptEnabled[policyType] = $("checkboxID_EnerceptEnabled").checked;
    EnterceptShowMessages[policyType] = $("checkboxID_EnterceptShowMessages").checked;

    if($("radioID_BOPProtectMode").checked)
    {
        EnterceptMode[g_CurrentPolicyType] = BLOCKING_MODE;
    }
    else
    {
        EnterceptMode[g_CurrentPolicyType] = WARNING_MODE;
    }


    logFileFormat[g_CurrentPolicyType] = $("selectID_LogFileFormat").selectedIndex;
    bLogToFile[g_CurrentPolicyType] = $("checkboxID_LogToFile").checked;
    szLogFileName[g_CurrentPolicyType] = $("textboxID_LogFileName").value;
    bLimitSize[g_CurrentPolicyType] = $("checkboxID_LimitLogFileSize").checked;
    dwMaxLogSizeMB[g_CurrentPolicyType] = $("textboxID_MaxLogSize").value;
}

function displayPolicyData(policyType)
{
    $("checkboxID_EnerceptEnabled").checked = EnterceptEnabled[policyType];
    $("checkboxID_EnterceptShowMessages").checked = EnterceptShowMessages[policyType];

    $("selectID_LogFileFormat").selectedIndex = logFileFormat[g_CurrentPolicyType];
    $("checkboxID_LogToFile").checked = bLogToFile[g_CurrentPolicyType];
    $("textboxID_LogFileName").value = szLogFileName[g_CurrentPolicyType];
    $("checkboxID_LimitLogFileSize").checked = bLimitSize[g_CurrentPolicyType];
    $("textboxID_MaxLogSize").value = dwMaxLogSizeMB[g_CurrentPolicyType];

    displayExclusionsLists(g_CurrentPolicyType);
    setBOPMode();
    fnEnableReportingTabUI();

    _doReadonly();
}

function fnSetAdvancedState( )
{
    var myrows;

    if(g_CurrentPolicyType == WRKSTN_POLICY)
    {
        myrows = g_WrkstnBOPExclusionsAddWidget.getList();
    }
    else
    {
        myrows = g_ServerBOPExclusionsAddWidget.getList();
    }

    for(var i in myrows)
    {
        if(g_CurrentPolicyType == WRKSTN_POLICY)
        {
            var currentItemID = myrows[i].replace("divID_WrkstnBOPExclusionsList_awrow_", "");
            $("wrkstn_bop_advanced_span_" + currentItemID).style.display = "";
        }
        else
        {
            var currentItemID = myrows[i].replace("divID_ServerBOPExclusionsList_awrow_", "");
            $("server_bop_advanced_span_" + currentItemID).style.display = "";
        }
    }
}