/**
@fileoverview
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
MaJiC ~ McAfee Javascript Interface Controls
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A collection of fun little javascript widgets and utilities
with a witty acronym. Broken down into "class" objects with
unique and hopefully appropriate namespaces.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

/*
    Namespace constructor for the majic range of tools.
    @private
*/
var majic = window.majic || {};

/**
SwapTabStrip
Builds a Tab Strip for swapping content. Unless otherwise
specified, uses Orion classes
@param {str} div The name of the container Div
@param {obj} names An associative array of div ids and tab titles
*/
majic.SwapTabStrip = function(div,names){
	var master = document.getElementById(div);
	var instn = this;
	this.cblist = {};

	// Outer Div 1
	var outdiv = document.createElement("DIV");
	outdiv.className="layout_box_24";
	outdiv.setAttribute("id","otsID_Tabs_container");
	// Outer Div 2
	var outdiv2 = document.createElement("DIV");
	outdiv2.className="orionTabStripContainer";
	// Table
	var table = document.createElement("TABLE");
	table.className = "orionTabStrip";
	table.setAttribute("id","otsID_Tabs");
	table.cellSpacing = 0;
	table.cellPadding = 0;
	// TBODY - Needed for IE - gg
	var tbody = document.createElement("TBODY");
	// TR
	var tr = document.createElement("TR");
	// TD LIST
	for(var i in names){
		var td = document.createElement("TD");
		var indiv = document.createElement("DIV");
		indiv.innerHTML = names[i].title;
		if(names[i].callback){
			this.cblist[i] = names[i].callback;
		}
		td.appendChild(indiv);
		var myname = "tab_"+i;
		td.setAttribute("id",myname);
		td.className = "orionTab";
		td.onclick = function(evt){
		    evt = evt || event;
            if (! evt.target){
                evt.target = evt.srcElement;
            }
            var p = evt.target.parentNode;
			instn.swap(p);
		}
		tr.appendChild(td);
	}
	tbody.appendChild(tr);
	table.appendChild(tbody);
	outdiv2.appendChild(table);
	outdiv.appendChild(outdiv2);
	master.appendChild(outdiv);

	//Auto swap #1
	this.swap(tr.childNodes[0]);
};

/**
* SwapTabStrip - swapping
* Swaps the tab to the selected one on the tab
* @param {obj} me The clicked on tab
*/
majic.SwapTabStrip.prototype.swap = function(me){
	var key = me.getAttribute("id").replace("tab_","");
	var TABS = me.parentNode.getElementsByTagName("TD");
	for(var i=0;i<=TABS.length;i++){
		if(TABS[i] !== undefined){
			var cls = TABS[i].getAttribute("id").replace("tab_","");
			if(cls == key){
				if(this.cblist !== undefined){
					if(this.cblist[key]){
						this.cblist[key]();
					}
				}
				TABS[i].className = "orionTabSelected";
				document.getElementById(cls).style.display = "block";
			}else{
				TABS[i].className = "orionTab";
				document.getElementById(cls).style.display = "none";
			}

        }
	}
}

/**
 * The opening "class" for the AddWidget (+/-) row adder
 * @param {obj} obj	An object holding the default parameters (container/content)
 * @return {obj} THe instance of the Widget
 */
majic.AddWidget = function(obj){
	this.cntrid = obj["container"];
	this.cntr = document.getElementById(obj["container"]);
	this.id = 0;
	this.list = {};
    this.addCallback = null;
    this.removeCallback = null;
    this.readOnly=false;
    this.icons = {
		"plus":"<img src='/core/images/button/add-button.gif' border='0' width='27' height='19' align='absmiddle'>",
		"minus":"<img src='/core/images/button/delete-button.gif' border='0' width='27' height='19' align='absmiddle'>"
	};
	this.content = "";
	if(obj["content"] != null){
	    this.content = obj["content"];
	}else{
	    this.content = "<INPUT TYPE='text' size='15' value='@VALUE'>";
	}
    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }
    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }
}
/**
 * The AddWidget method for adding new rows
 * @param {obj} inval   An object holding any replacements for placeholders in the HTML content
 * @return void
 */
majic.AddWidget.prototype.add = function(inval){
	this.id++;
	var newbox = document.createElement('div');
	newbox.setAttribute("id",this.cntrid+"_awrow_"+this.id);
	newbox.setAttribute("style","margin-bottom: 3px;");

    var contentSpan = document.createElement('span');
    contentSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_content");

    var buttonSpan = document.createElement('span');
    buttonSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_buttons");

    newbox.appendChild(contentSpan);
    newbox.appendChild(buttonSpan);

    if(inval == null){
	    inval = {"@VALUE":""};
	}

    // add or update our default @ID attribute
    inval["@ID"]=this.id;

    var field = this.content;
	for(var i in inval){
        // let's replace all instances.  Don't want to worry about regex quoting, this is easy:
        while(field.indexOf(i)!=-1)
        {
            field = field.replace(i,inval[i]);
        }
    }

    contentSpan.innerHTML = field;

    this.cntr.appendChild(newbox);
	this.list[this.cntrid+"_awrow_"+this.id] = true;

    this.toggle();

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newbox);
    }
}
/**
 * The AddWidget method for placing the plus and minus buttons on the screen.
 */
majic.AddWidget.prototype.toggle = function(){
    // Due to scope loss in the add/remove, the buttons are redrawn on every click.

    // Add Minuses
    var instn = this;
    var psave = 0;

    // clear out buttons
    for (var i in this.list) {
        var span = document.getElementById(i + "_buttons");
        if (span != null) {
            span.innerHTML = "";
        }
    }

    // don't add any buttons if the adder is read-only
    if (!this.readOnly){
        // Ugly roll to accomodate the Mercury style of having no minus on the first row.
        var trues = 0;
        for (var i in this.list) {
            if (this.list[i]) {
                trues++;
            }
        }
        for (var i in this.list) {
            if (this.list[i]) {
                if (trues > 1) { // ugly from above
                    var div = document.getElementById(i);
                    var span = document.getElementById(i + "_buttons");
                    if (span != null)
                    {
                        var space = document.createElement('SPAN');
                        space.innerHTML = "&nbsp;";
                        span.appendChild(space);
                        var minus = document.createElement('a');
                        minus.setAttribute("href", "javascript:;");
                        minus.onclick = function(evt)
                        {
                            evt = evt || event;
                            if (! evt.target) {
                                evt.target = evt.srcElement;
                            }
                            instn.remove(evt.target);
                        }
                        minus.innerHTML = this.icons["minus"];
                        span.appendChild(minus);
                    }
                }
                psave = i;
            }
        }

        // Add plus to last element
        var psave = document.getElementById(psave + "_buttons");
        var space = document.createElement('SPAN');
        space.innerHTML = "&nbsp;";
        psave.appendChild(space);

        var adder = document.createElement('a');
        adder.setAttribute("href", "javascript:;");
        adder.onclick = function()
        {
            instn.add();
        }
        adder.innerHTML = this.icons["plus"];
        psave.appendChild(adder);
        if (psave.style.display == "block") {
            psave.childNodes[0].focus();
        }
    }
}
/**
 * The AddWidget method for removing rows
 * @param {obj} me   The row to remove
 * @return void
 */
majic.AddWidget.prototype.remove = function(me){
    var mom = me.parentNode.parentNode.parentNode;
    if(this.removeCallback != null){
        this.removeCallback();
    }
 	if(this.cntr.childNodes.length > 1){
 	    this.list[mom.getAttribute("id")] = false;
		mom.parentNode.removeChild(mom);
	}else{
	    mom.childNodes[0].value = "";
	}
	this.toggle();
}

/**
 * Retrieves the names of the rows.
 * @return {array} A collection list of DIV tags row names.
 */
majic.AddWidget.prototype.getList = function(){
	var its = new Array();
	for(i in this.list){
		if(this.list[i]){
		    its.push(i);
        }
	}
	return its;
}
/**
 * Retrieves the iteration numbers of the rows. Use this to get out the values of
 * fields using @ID
 * @return {array} An array of row numbers.
 */
majic.AddWidget.prototype.getRowIds = function(){
	var rws = this.getList();
	var ids = new Array();
	for (var i=0; i < rws.length; i++) {
		var cut = rws[i].split("_");
		ids.push(cut.pop());
	};
	return ids;
}
/**
 * Retrieves object references to the div rows.
 * @return {obj} A collection list of DIV objects objects with content in them.
 */
majic.AddWidget.prototype.getRows = function(){
	var its = {};
	for(i in this.list){
		if(this.list[i]){
			var cut = i.split("_");
		    its[cut[2]] = document.getElementById(i);
        }
	}
	return its;
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Utilities
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/**
* Grab GET variables from the URL string.
* @return {array} variables key/value
*/
majic.getUrlArgs = function (){
	var args = {};
	var loc = window.location.href;
	var q = loc.indexOf("?");
	if (q==-1){
		return false;
	}
	loc = loc.substring(q+1);
	var pairs = loc.split("&");
	for (var i=0; i<pairs.length;i++){
		var keyval = pairs[i].split("=");
		args[keyval[0]] = unescape(keyval[1]);
	}
	return args;
}

/**
 * The shortcut method for toggling sections off and on based on checkbox.
 * @param {object} me The checkbox element doing the toggling.
 * @param {string} sect The name of the div element to toggle.
*/
majic.toggleSection = function(me,sect){
	majic.toggleEnabled(me.checked,sect);
}

/**
 * The shortcut method for toggling sections off and on based on checkbox,
 * in reverse. Checked disables, unchecked enables.
 * @param {object} me The checkbox element doing the toggling.
 * @param {string} sect The name of the div element to toggle.
*/
majic.toggleSectionBackwards = function(me,sect){
	var backwards = (me.checked) ? false : true;
	majic.toggleEnabled(backwards,sect);
}

/**
 * The method for toggling sections off and on
 * @param {bool} state The state of the section
 * @param {string} sect The name of the div element to toggle.
*/
majic.toggleEnabled = function(state,sect){
	var sectd = document.getElementById(sect);
	var slistt = new Array();
	var slist = slistt.concat(__arrayme(sectd.getElementsByTagName("LABEL")),
		__arrayme(sectd.getElementsByTagName("INPUT")),
		__arrayme(sectd.getElementsByTagName("SELECT")),
		__arrayme(sectd.getElementsByTagName("TEXTAREA")));
	for(var i=0;i<slist.length;i++){
		OrionCore.setEnabled(slist[i],state);
	}
	function __arrayme(obj){
		var n = new Array();
		for(var j=0;j<obj.length;j++){
			n.push(obj[j]);
		}
		return n;
	}
}
