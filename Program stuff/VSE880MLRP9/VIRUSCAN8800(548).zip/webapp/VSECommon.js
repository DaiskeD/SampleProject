var VSE = window.VSE || {};

// Added this flag due to the fact that we are not initializing any of the form
// elements when they are loaded. This is because the data in the form is populated
// based on which policy type (server/wrkstn) is selected.
var g_FirstValidationCheck = true;

var g_CurrentPolicyType;
var WRKSTN_POLICY = 0;
var SERVER_POLICY = 1;

// Used for macro validation, these strings should NOT be localized!
var g_szValidMacros = new Array();
g_szValidMacros[0]	= "SYSTEM_DRIVE";
g_szValidMacros[1]	= "SYSTEM_ROOT";
g_szValidMacros[2]	= "SYSTEM_DIR";
g_szValidMacros[3]	= "TEMP_DIR";
g_szValidMacros[4]	= "PROGRAM_FILES_DIR";
g_szValidMacros[5]	= "PROGRAM_FILES_COMMON_DIR";
g_szValidMacros[6]	= "SOFTWARE_INSTALLED_DIR";
g_szValidMacros[7]	= "COMPUTER_NAME";
g_szValidMacros[8]	= "USER_NAME";
g_szValidMacros[9]	= "DOMAIN_NAME";

var g_szValidMacroValues = new Array();
g_szValidMacroValues[0]	= "<SYSTEM_DRIVE>\\";
g_szValidMacroValues[1]	= "<SYSTEM_ROOT>\\";
g_szValidMacroValues[2]	= "<SYSTEM_DIR>\\";
g_szValidMacroValues[3]	= "<TEMP_DIR>\\";
g_szValidMacroValues[4]	= "<PROGRAM_FILES_DIR>\\";
g_szValidMacroValues[5]	= "<PROGRAM_FILES_COMMON_DIR>\\";
g_szValidMacroValues[6]	= "<SOFTWARE_INSTALLED_DIR>\\";
g_szValidMacroValues[7]	= "<COMPUTER_NAME>";
g_szValidMacroValues[8]	= "<USER_NAME>";
g_szValidMacroValues[9]	= "<DOMAIN_NAME>";

var g_Disabled = false;

/**
 * This is called whenever the policy type is toggled in the UI.
 *
 * All policies must implement the storePolicyData and displayPolicyData functions
 */
function onPolicyTypeToggle(policyType)
{
    if(g_CurrentPolicyType != policyType)
    {
        storePolicyData(g_CurrentPolicyType);
        g_CurrentPolicyType = policyType;
    }

    displayPolicyData(policyType);
}

/**
 * The opening "class" for the AddWidget (+/-) row adder
 * @param {obj} obj	An object holding the default parameters (container/content)
 * @return {obj} THe instance of the Widget
 */
VSE.AddWidget = function(obj){

    this.cntrid = obj["container"];
	this.cntr = document.getElementById(obj["container"]);
	this.id = 0;
	this.list = {};
    this.addCallback = null;
    this.removeCallback = null;
    this.readOnly=false;
    this.icons = {
		"plus":"<img src='/core/images/button/add-button.gif' border='0' width='27' height='19' align='absmiddle'>",
		"minus":"<img src='/core/images/button/delete-button.gif' border='0' width='27' height='19' align='absmiddle'>"
	};
	this.content = "";
	if(obj["content"] != null){
	    this.content = obj["content"];
	}else{
	    this.content = "<INPUT TYPE='text' size='15' value='@VALUE'>";
	}
    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }
    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }
}
/**
 * The AddWidget method for adding new rows
 * @param {obj} inval   An object holding any replacements for placeholders in the HTML content
 * @return void
 */
VSE.AddWidget.prototype.add = function(inval){

    if(g_Disabled)
    {
        return;
    }

    this.id++;
	var newbox = document.createElement('div');
	newbox.setAttribute("id",this.cntrid+"_awrow_"+this.id);
	newbox.setAttribute("style","margin-bottom: 3px;");

    var contentSpan = document.createElement('span');
    contentSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_content");

    var buttonSpan = document.createElement('span');
    buttonSpan.setAttribute("id",this.cntrid+"_awrow_"+this.id+"_buttons");

    newbox.appendChild(contentSpan);
    newbox.appendChild(buttonSpan);

    if(inval == null){
	    inval = {"@VALUE":""};
	}

    // Store the @VALUE from the passed in object
    var hiddenValue = document.createElement('input');
    hiddenValue.setAttribute("id",this.cntrid+"_hiddenvalue_"+this.id);
    hiddenValue.setAttribute("value", inval["@VALUE"]);
    hiddenValue.setAttribute("type", "hidden");
    newbox.appendChild(hiddenValue);
    
    // add or update our default @ID attribute
    inval["@ID"]=this.id;

    var field = this.content;
	for(var i in inval){
        // let's replace all instances.  Don't want to worry about regex quoting, this is easy:
        while(field.indexOf(i)!=-1)
        {
            field = field.replace(i,inval[i]);
        }
    }

    contentSpan.innerHTML = field;

    this.cntr.appendChild(newbox);
    this.list[this.cntrid+"_awrow_"+this.id] = true;

    this.toggle();

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newbox);
    }
}
/**
 * The AddWidget method for placing the plus and minus buttons on the screen.
 */
VSE.AddWidget.prototype.toggle = function(){
    // Due to scope loss in the add/remove, the buttons are redrawn on every click.

    // Add Minuses
    var instn = this;
    var listLength = this.cntr.childNodes.length;
    var psave = 0;
    var currentItem = 0;

    for (var i in this.list) {
        ++currentItem;
        if (this.list[i]) {
            var span = document.getElementById(i + "_buttons");
            if (span != null)
            {
                if(!this.readOnly)
                {
                    // clear the item if it has the add button so it will get added to the last item
                    if(document.getElementById(i+"_adder") != null)
                    {
                        span.innerHTML = "";
                    }

                    // only add the minus if it doesn't already exist
                    if(document.getElementById(i+"_minus") == null)
                    {
                        var space = document.createElement('SPAN');
                        space.innerHTML = "&nbsp;";
                        span.appendChild(space);

                        var minus = document.createElement('a');
                        minus.setAttribute("href", "javascript:;");
                        minus.setAttribute("id",i+"_minus");
                        minus.onclick = function(evt)
                        {
                            evt = evt || event;
                            if (! evt.target) {
                                evt.target = evt.srcElement;
                            }
                            instn.remove(evt.target);
                        }

                        minus.innerHTML = this.icons["minus"];

                        span.appendChild(minus);
                    }
                }
                else
                {
                    span.innerHTML = "";
                }
            }
            psave = i;
        }
    }

    // Add plus to last element
    var lastElement = document.getElementById(psave + "_buttons");
    var space = document.createElement('SPAN');
    space.innerHTML = "&nbsp;";
    lastElement.appendChild(space);

    var adder = document.createElement('a');
    adder.setAttribute("href", "javascript:;");
    adder.setAttribute("id",psave+"_adder");
    adder.onclick = function()
    {
        instn.add();
    }
    adder.innerHTML = this.icons["plus"];
    lastElement.appendChild(adder);
    if (lastElement.style.display == "block") {
        lastElement.childNodes[0].focus();
    }
}
/**
 * The AddWidget method for removing rows
 * @param {obj} me   The row to remove
 * @return void
 */
VSE.AddWidget.prototype.remove = function(me){

   if(g_Disabled)
   {
        return;
   }

    var mom = me.parentNode.parentNode.parentNode;
    // if we're removing the last item in the list, add a blank item first.
    if(this.cntr.childNodes.length == 1)
    {
        this.add({"@VALUE":""})
    }

    if(this.cntr.childNodes.length > 1)
    {
 	    this.list[mom.getAttribute("id")] = false;
		mom.parentNode.removeChild(mom);
	}
    else
    {
	    mom.childNodes[0].value = "";
	}
	this.toggle();

    if(this.removeCallback != null)
    {
        this.removeCallback();
    }
}
/**
 * The AddWidget method for retreiving active rows
 * @return {array} A collection list of DIV tags objects with content in them.
 */
VSE.AddWidget.prototype.getList = function(){
	var its = new Array();
	for(i in this.list){
		if(this.list[i]){
		    its.push(i);
        }
	}
	return its;
}

VSE.AddWidget.prototype.getRows = function(){
	var its = {};
	for(i in this.list){
		if(this.list[i]){
			var cut = i.split("_");
		    its[cut[2]] = document.getElementById(i);
        }
	}
	return its;
}

VSE.AddWidget.prototype.clearList = function()
{
    while(this.cntr.childNodes.length>0)
    {
        this.cntr.removeChild(this.cntr.childNodes[0]);
    }

    this.list = {};
    this.id = 0;
    this.selectedRow = "undefined";

    this.add({"@VALUE":""})
}

/****************************************************************************/
/* List Item for use with the List Widget                                   */
/****************************************************************************/
VSE.ListItem = function(){
    this.displayText = "";
    this.itemData = null;
    this.itemChecked = false;
}

VSE.ListItem.prototype = {
    setDisplayText : function(text)
    {
        this.displayText = text;
    }
    ,
    setItemData : function(data)
    {
        this.itemData = data;        
    }
    ,
    setItemChecked : function(checked)
    {
        this.itemChecked = checked;
    }
}

/****************************************************************************/
/* VSE.ListWidget                                                           */
/*                                                                          */
/* Displays a list of VSE.ListItem objects and allows the inclusion of a    */
/* checkbox for the item.                                                   */
/****************************************************************************/
VSE.ListWidget = function(obj){
	this.cntrid = null;
	this.cntr = null;
	this.id = 0;
	this.list = {};                         // an array of VSE.ListItem objects
    this.addCallback = null;
    this.removeCallback = null;
    this.onchangeSelectionCallback = null;
    this.checkboxCallback = null;
    this.readOnly=false;
    this.width = 600;
    this.height = 150;
    this.listTable = null;
    this.checkboxCount = 0;
    this.objectName = obj["objectName"];
    this.content="";

    if(obj["container"] != null)
    {
        this.cntrid = obj["container"];
        this.cntr = document.getElementById(obj["container"]);
    }

    if(obj["content"] != null)
    {
        this.content = obj["content"];
    }

    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }

    if(obj["onchangeSelectionCallback"] != null)
    {
        this.onchangeSelectionCallback = obj["onchangeSelectionCallback"];
    }

    if(obj["checkboxCallback"] != null)
    {
        this.checkboxCallback = obj["checkboxCallback"];
    }

    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }

    if(obj["width"] != null)
    {
        this.width = obj["width"];
    }

    if(obj["height"] != null)
    {
        this.height = obj["height"];
    }

    if(obj["checkboxCount"] != null)
    {
        this.checkboxCount = obj["checkboxCount"];
    }

    if(obj["data"] != null)
    {
        this.data = obj["data"];
    }

    // create the table to contain the list
    if(this.cntr != null)
    {
        var listDiv = document.createElement('div');
        listDiv.style.overflow = "auto";
        listDiv.style.width = "" + this.width + "px";
        var browserVersion = getBrowserVersion();

        if(browserVersion > 0 && browserVersion < 7)
        {
            listDiv.style.height = "" + this.height + "px";

        }
        else
        {
            listDiv.style.minHeight = "" + this.height + "px";
            listDiv.style.maxHeight = "1px";
        }
        listDiv.style.borderStyle = "solid";
        listDiv.style.borderWidth = "thin";
        listDiv.style.padding = "0px";
        listDiv.style.margin = "0px";
        
        this.listTable = document.createElement('table');
	    this.listTable.id = this.cntrid+"_listContainer";
	    this.listTable.width = this.width;
        this.listTable.cellPadding = 0;
        this.listTable.cellSpacing = 0;
        this.listTable.border = 0;
        this.selectedRow = "undefined";

        listDiv.appendChild(this.listTable);
        this.cntr.appendChild(listDiv);
    }
}

VSE.ListWidget.prototype.add = function(listItem)
{
    if(listItem == null)
    {
        return;
    }
    this.id++;

    // Create a new row in the table
    var newRow = this.listTable.insertRow(this.listTable.rows.length);
    newRow.id = this.cntrid + "_lwrow_" + this.id;

    // this is the text for the function call to be used for onclick events to handle the selection
    // and unselection of the table rows.
    var selectRowFunctionCall = this.objectName + ".SelectRow('" + newRow.id + "');";
    
    // add the checkbox cell to the row if needed
    var cellCount = 0;
    for(var i=0; i < this.checkboxCount; ++i)
    {
        var checkboxColumn = newRow.insertCell(cellCount);
        ++cellCount;
        var checkboxID = newRow.id + "_checkbox" + i;
        checkboxColumn.width = 25;
        checkboxColumn.setAttribute("onclick", selectRowFunctionCall);

        var checkboxElement = document.createElement('input');
        checkboxElement.type = "checkbox";
        checkboxElement.name = checkboxID;
        checkboxElement.id = checkboxID;
        checkboxElement.checked = listItem.itemChecked;
        checkboxColumn.appendChild(checkboxElement);
        // this is essentially the same as the code above, except that the code above does not work on IE.
        $(checkboxID).checked = listItem.itemChecked;
        if(this.checkboxCallback != null)
        {
            $(checkboxID).onclick = this.checkboxCallback;
        }
    }

    var contentColumn = newRow.insertCell(cellCount);
    ++cellCount;
    contentColumn.id = this.cntrid + "_lwrow_" + this.id + "_content";
    contentColumn.setAttribute("onclick", selectRowFunctionCall);

    var contentHref = document.createElement('a');
    contentHref.href = "JavaScript:" + selectRowFunctionCall;
    contentHref.style.textDecoration = "none";
    contentHref.id = newRow.id + "_contentHref";
    contentHref.innerHTML = listItem.displayText;
    contentColumn.appendChild(contentHref);

    this.list[this.cntrid+"_lwrow_"+this.id] = listItem;

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newRow);
    }
}

VSE.ListWidget.prototype.getItemList = function()
{
    var items = new Array();
    for(i in this.list)
    {
        if(this.list[i])
        {
            this.list[i].itemChecked = $(i+"_checkbox").checked;
            items.push(this.list[i]);
        }
    }

    return items;
}

VSE.ListWidget.prototype.renameSelected = function(name)
{
    if(this.selectedRow != "undefined")
    {
        $(this.selectedRow + "_contentHref").innerHTML = name;
    }
}

VSE.ListWidget.prototype.removeSelected = function()
{
    if(this.selectedRow != "undefined")
    {
        for(var i=0; i < this.listTable.rows.length; ++i)
        {
            if(this.listTable.rows[i].id == this.selectedRow)
            {
                this.unhighlightRow(this.selectedRow);
                this.listTable.deleteRow(i);
                this.list[this.selectedRow] = null;
                this.selectedRow = "undefined";

                break;
            }
        }
    }
}

VSE.ListWidget.prototype.SelectRow = function(rowID)
{
    var previousRow = "";
    if(this.selectedRow != "undefined")
    {
        previousRow = this.selectedRow;
        this.unhighlightRow(this.selectedRow);
    }

    this.highlightRow(rowID);
    this.selectedRow = rowID;

    // the selection change callback should only be called when the selection
    // actually changes.
    if(this.onchangeSelectionCallback != null && (previousRow != this.selectedRow))
    {
        this.onchangeSelectionCallback(this.list[this.selectedRow]);
    }
}

VSE.ListWidget.prototype.highlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "lightsteelblue";
}

VSE.ListWidget.prototype.unhighlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "white";
}

VSE.ListWidget.prototype.getSelected = function()
{
    if(this.selectedRow == "undefined")
    {
        return null;
    }
    else
    {
        return this.list[this.selectedRow];
    }
}

VSE.ListWidget.prototype.getItem = function(rowID)
{
    return this.list[rowID];
}

VSE.ListWidget.prototype.clearList = function()
{
    for(var i = this.listTable.rows.length-1; i > -1; i--)
    {
        this.listTable.deleteRow(i)
    }
    this.list = {};
    this.id = 0;
    this.selectedRow = "undefined";
}

function numbers_only(e)
{
    var k;

    k = document.all?e.keyCode:e.which;

    // Firefox specific -- special cases for backspace, delete, and arrow keys
    if(!document.all)
    {
        var key = e.keyCode;

        if(key==8 || key==46 || (key>36 && key<41))
        {
            return true;
        }
    }

    // allow numbers, backspaces, delete, and arrow keys
    return (k>47 && k<58);
}

function MaxTextLength(e, iMax)
{
    var textLength = e.value.length;
    if (textLength > iMax)
    {
        e.value = e.value.slice(0,iMax);
        //event.returnValue = false;
    }
}

function TclFormat(szStringToFormat)
{
	var szFormattedString = "";
	var bNeedsQuotes = false;

	if(szStringToFormat.search(/ /) != -1)
	{
		szFormattedString = "\"";
		bNeedsQuotes = true;
	}

	for(var i = 0; i < szStringToFormat.length; ++i)
	{
		var outVal = "";
		switch(szStringToFormat.charAt(i))
		{
		//case '\a': outVal = "a"; break; // \a not a valid escape sequence in JS
		case '\b': outVal = 'b'; break;
        case '\f': outVal = 'f'; break;
        case '\n': outVal = 'n'; break;
        case '\r': outVal = 'r'; break;
        case '\t': outVal = 't'; break;
        //case '\v': outVal = 'v'; break; // \v not a valid escape sequence in JS
        case '\\': outVal = '\\'; break;
        case '\"': outVal = '\"'; break;
        case '\'': outVal = '\''; break;
        case '{':  outVal = '{'; break;
        case '}':  outVal = '}'; break;
        case '[':  outVal = '['; break;
        case ']':  outVal = ']'; break;
        case '$':  outVal = '$'; break;
        case ';':  outVal = ';'; break;
        case '#':  outVal = '#'; break;
		}

		if(outVal != "")
		{
			szFormattedString += "\\" + outVal;
		}
		else
		{
			szFormattedString += szStringToFormat.charAt(i);
		}
	}

	if(bNeedsQuotes)
		szFormattedString += "\"";

	return szFormattedString;
}

function RemoveTclFormat(szTclString)
{
	var szNonTclString = "";
	var bRemoveQuotes = false;
	var i = 0;

	if(szTclString.charAt(0) == '\"' && szTclString.charAt(szTclString.length - 1) == '\"')
	{
		bRemoveQuotes = true;
		i = 1;
	}

	for( ; i < szTclString.length; ++i)
	{
		var outVal = "";
		if(szTclString.charAt(i) == '\\')
		{
			++i;
			if(i < szTclString.length)
			{
				switch(szTclString.charAt(i))
				{
				case 'b': outVal = '\b'; break;
				case 'f': outVal = '\f'; break;
				case 'n': outVal = '\n'; break;
				case 'r': outVal = '\r'; break;
				case 't': outVal = '\t'; break;
				case '\\': outVal = '\\'; break;
				case '\"': outVal = '\"'; break;
				case '\'': outVal = '\''; break;
				case '{':  outVal = '{'; break;
				case '}':  outVal = '}'; break;
				case '[':  outVal = '['; break;
				case ']':  outVal = ']'; break;
				case '$':  outVal = '$'; break;
				case ';':  outVal = ';'; break;
				case '#':  outVal = '#'; break;
				}
			}
			else
			{
				--i;
			}
		}

		if(outVal != "")
		{
			szNonTclString += outVal;
		}
		else
		{
			szNonTclString += szTclString.charAt(i);
		}
	}

	if(bRemoveQuotes && szNonTclString.charAt(szNonTclString.length - 1) == '\"')
		szNonTclString = szNonTclString.substring(0, szNonTclString.length-1);

	return szNonTclString;
}

function disableSection(sectionId,enable)
{
    var section = document.getElementById(sectionId);
    var slist = getElementsAsArray(sectionId);

    for(var i=0;i<slist.length;i++){
        //OrionCore.setEnabled(slist[i],enable);
        slist[i].disabled = !enable;
    }

    g_Disabled = !enable;
}

function getElementsAsArray(sectionId)
{
    var sectd = document.getElementById(sectionId);
    var slistt = new Array();
    var slist = slistt.concat(__arrayme(sectd.getElementsByTagName("LABEL")),
        __arrayme(sectd.getElementsByTagName("INPUT")),
        __arrayme(sectd.getElementsByTagName("SELECT")),
        __arrayme(sectd.getElementsByTagName("TEXTAREA")));

    return slist;

    function __arrayme(obj){
        var n = new Array();
        for(var j=0;j<obj.length;j++){
            n.push(obj[j]);
        }
        return n;
    }
}

function IsValidPath(szPath)
{
	var r;

	r = szPath.indexOf("/");

	if(r == -1)
		r = szPath.indexOf("\*");

	if(r == -1)
		r = szPath.indexOf("?");

	if(r == -1)
		r = szPath.indexOf("\"");

	if(r == -1)
		r = szPath.indexOf("|");

    if(r == -1)
		r = szPath.indexOf("<");

    if(r == -1)
		r = szPath.indexOf(">");

    if(r == -1)
		return true;

	return false;
}

function IsValidMacro(szStr)
{
	var i = 0;
	var bFoundMatchingMacroValue = false;

	var bValidMacros = false, nEndMacro = 0, nStartMacro = 0;
	var nNumberOfGr = 0, nNumberOfLs = 0, nMacro = 0;

	// Find number of <
	while(1)
	{
		nMacro = szStr.indexOf("<", nMacro);
		if(nMacro != -1)
		{
			nNumberOfGr = nNumberOfGr + 1;
			nMacro = nMacro + 1;
		}
		else
			break;
	}

	nMacro = 0;
	while(1)
	{
		nMacro = szStr.indexOf(">", nMacro);
		if(nMacro != -1)
		{
			nNumberOfLs = nNumberOfLs + 1;
			nMacro = nMacro + 1;
		}
		else
			break;
	}


	while(nNumberOfLs == nNumberOfGr)
	{
		nStartMacro = szStr.indexOf("<", nEndMacro);
		if(nStartMacro != -1)
		{
			bValidMacros = false;
			nStartMacro = nStartMacro + 1;
		}
		else
		{
			nEndMacro = szStr.indexOf(">", nEndMacro);
			if(nEndMacro == -1)
			{
				bValidMacros = true;
			}
			else
			{
				bValidMacros = false;
			}

			break;
		}

		nEndMacro = szStr.indexOf(">", nStartMacro);
		if(nEndMacro != -1)
		{
			if(szStr.substring(nStartMacro, nEndMacro) == "")
			{
				// alert("Blank Macro");
				bValidMacros = false;
				break;
			}
			else
			{
				var szStr1 = szStr.substring(nStartMacro, nEndMacro);
				if(szStr1.indexOf("<") == -1)
				{
					bValidMacros = true;
					nEndMacro = nEndMacro + 1;
				}
				else
				{
					bValidMacros = false;
					break;
				}

				bFoundMatchingMacroValue = false;

				for (i=0; i < g_szValidMacros.length; i++)
					if ( g_szValidMacros[i] == szStr1 )
						bFoundMatchingMacroValue = true;

				if (!bFoundMatchingMacroValue)
				{
					bValidMacros = false;
					break;
				}
			}
		}
		else
		{
			bValidMacros = false;
			break;
		}
	}

	return bValidMacros;
}

function validateQuarantineFolder(szQuarantineFolder)
{
    if(szQuarantineFolder == null || szQuarantineFolder =="")
    {
        return false;
    }

    if(szQuarantineFolder.indexOf( "\\\\", 1 )  > 0)
    {
        return false;
    }

    if(szQuarantineFolder.indexOf( "\\\\" )  == 0)
    {
        return false;
    }

    if(!IsValidMacro(szQuarantineFolder))
    {
        return false;
    }

    var r;

    r = szQuarantineFolder.indexOf("/");

	if(r == -1)
		r = szQuarantineFolder.indexOf("\*");

	if(r == -1)
		r = szQuarantineFolder.indexOf("?");

	if(r == -1)
		r = szQuarantineFolder.indexOf("\"");

	if(r == -1)
		r = szQuarantineFolder.indexOf("|");

    if(r == -1)
		return true;

    return false;
}

function validateLogfilePath(szLogPath)
{
    var valid = true;

    if($("checkboxID_LogToFile").checked)
    {
        if((szLogPath == ""))
        {
            return false;
        }

        var r;

        r = szLogPath.indexOf("/");

        if(r == -1)
            r = szLogPath.indexOf("\*");

        if(r == -1)
            r = szLogPath.indexOf("?");

        if(r == -1)
            r = szLogPath.indexOf("\"");

        if(r == -1)
            r = szLogPath.indexOf("|");

        valid = (r == -1);

        if(valid && !IsValidMacro(szLogPath))
        {
            valid = false;
        }
    }

    return valid;
}

function validateMaxLogSize(szMaxLogSize)
{
    var valid = true;

    if($("checkboxID_LimitLogFileSize").checked)
    {
        if(szMaxLogSize < 1)
        {
            valid = false;            
        }
    }

    return valid;
}

// ===========================================================================
// Called by orion whenever the state of the form changes (checkbox checked,
// textbox edited, etc.)
//
// We use this to deteremine whether or not the Apply button should be
// enabled
// ===========================================================================
function stateChangeHandler( isDirty, isValid )
{
    $("selectID_PolicyTypeToggle").disabled = !isValid;
    if(isDirty && !g_FirstValidationCheck && isValid)
    {
        epoEnableApplyButton();
    }
    else
    {
        epoDisableApplyButton();
    }

    // Now that the form has been validated, we're past the first check, so
    // set this flag to false.
    if(g_FirstValidationCheck)
    {
        g_FirstValidationCheck = false;
    }
}
function getBrowserVersion()
{
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf ( "MSIE " );
    var ver = 0;

    if ( msie > 0 )
    {
        // If Internet Explorer, return version number
        ver = parseInt (ua.substring (msie+5, ua.indexOf (".", msie )));
    }

    return ver;
}
