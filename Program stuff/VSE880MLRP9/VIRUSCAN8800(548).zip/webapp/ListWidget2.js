/****************************************************************************/
/* List Item for use with the List Widget                                   */
/****************************************************************************/
VSE.ListItem2 = function(){
    this.itemData = null;
}

VSE.ListItem2.prototype = {
    setDisplayText : function(text)
    {
        this.displayText = text;
    }
    ,
    setItemData : function(data)
    {
        this.itemData = data;
    }
    ,
    setItemChecked : function(checked)
    {
        this.itemChecked = checked;
    }
}

/****************************************************************************/
/* VSE.ListWidget2                                                           */
/*                                                                          */
/* Displays a list of VSE.ListItem2 objects and allows the inclusion of a    */
/* checkbox for the item.                                                   */
/****************************************************************************/
VSE.ListWidget2 = function(obj){
	this.cntrid = null;
	this.cntr = null;
	this.id = 0;
	this.list = {};                         // an array of VSE.ListItem2 objects
    this.addCallback = null;
    this.removeCallback = null;
    this.selectedRowUpdateCallback = null;
    this.onchangeSelectionCallback = null;
    this.checkboxCallback = null;
    this.readOnly=false;
    this.width = 600;
    this.height = 150;
    this.listTable = null;
    this.checkboxCount = 0;
    this.objectName = obj["objectName"];
    this.content="";
    this.thisObject = obj["thisObject"];

    if(obj["container"] != null)
    {
        this.cntrid = obj["container"];
        this.cntr = document.getElementById(obj["container"]);
    }

    if(obj["content"] != null)
    {
        this.content = obj["content"];
    }

    if(obj["addCallback"] != null)
    {
        this.addCallback = obj["addCallback"];
    }

    if(obj["removeCallback"] != null)
    {
        this.removeCallback = obj["removeCallback"];
    }

    if(obj["selectedRowUpdateCallback"] != null)
    {
        this.selectedRowUpdateCallback = obj["selectedRowUpdateCallback"];
    }

    if(obj["onchangeSelectionCallback"] != null)
    {
        this.onchangeSelectionCallback = obj["onchangeSelectionCallback"];
    }

    if(obj["checkboxCallback"] != null)
    {
        this.checkboxCallback = obj["checkboxCallback"];
    }

    if(obj["readOnly"] != null)
    {
        this.readOnly = obj["readOnly"];
    }

    if(obj["width"] != null)
    {
        this.width = obj["width"];
    }

    if(obj["height"] != null)
    {
        this.height = obj["height"];
    }

    if(obj["checkboxCount"] != null)
    {
        this.checkboxCount = obj["checkboxCount"];
    }

    if(obj["data"] != null)
    {
        this.data = obj["data"];
    }

    // create the table to contain the list
    if(this.cntr != null)
    {
        var listDiv = document.createElement('div');
        listDiv.style.overflow = "auto";
        listDiv.style.width = "" + this.width + "px";
        var browserVersion = getBrowserVersion();

        if(browserVersion > 0 && browserVersion < 7)
        {
            listDiv.style.height = "" + this.height + "px";

        }
        else
        {
            listDiv.style.minHeight = "" + this.height + "px";
            listDiv.style.maxHeight = "1px";	
        }
        listDiv.style.borderStyle = "solid";
        listDiv.style.borderWidth = "thin";
        listDiv.style.padding = "0px";
        listDiv.style.margin = "0px";

        this.listTable = document.createElement('table');
	    this.listTable.id = this.cntrid+"_listContainer";
	    this.listTable.width = this.width;
        this.listTable.cellPadding = 0;
        this.listTable.cellSpacing = 0;
        this.listTable.border = 0;
        this.selectedRow = "undefined";

        listDiv.appendChild(this.listTable);
        this.cntr.appendChild(listDiv);
    }
}

VSE.ListWidget2.prototype.add = function(listItem)
{
    if(listItem == null)
    {
        return;
    }
    this.id++;

    // Create a new row in the table
    var newRow = this.listTable.insertRow(this.listTable.rows.length);
    newRow.id = this.cntrid + "_lwrow_" + this.id;
    newRow.style.cursor = "pointer";

    // this is the text for the function call to be used for onclick events to handle the selection
    // and unselection of the table rows.
    var selectRowFunctionCall = this.objectName + ".SelectRow('" + newRow.id + "');";
    newRow.onmouseup = function() {rowClickListener(this.id);};


    // add the checkbox cell to the row if needed
    var cellCount = 0;

    var contentColumn = newRow.insertCell(cellCount);
    ++cellCount;
    contentColumn.id = this.cntrid + "_lwrow_" + this.id + "_content";

    // add or update our default @ID attribute
    var field = this.content;
    while(field.indexOf("@ID")!=-1)
    {
        field = field.replace("@ID",this.id);
    }
    
    //contentHref.innerHTML = listItem.displayText;
    contentColumn.innerHTML = field;

    // add a hidden href to table row
    // This href contains the code that will be called to select the row
    var contentHref = document.createElement('a');
    contentHref.href = "JavaScript:" + selectRowFunctionCall;
    contentHref.style.textDecoration = "none";
    contentHref.style.display = "none";
    contentHref.id = newRow.id + "_SelectRow";
    contentHref.innerHTML = listItem.displayText;
    newRow.appendChild(contentHref);

    this.list[this.cntrid+"_lwrow_"+this.id] = listItem;

    // call the add callback if one is set
    if(this.addCallback != null)
    {
        this.addCallback(newRow);
    }
}

VSE.ListWidget2.prototype.getItemList = function()
{
    var items = new Array();
    for(i in this.list)
    {
        if(this.list[i])
        {
            items.push(this.list[i]);
        }
    }

    return items;
}

VSE.ListWidget2.prototype.selectedRowUpdate = function()
{
    if(this.selectedRow != "undefined" && this.selectedRowUpdateCallback != null)
    {
        var selectedRowElement = $(this.selectedRow);
        if(selectedRowElement != null)
        {
            this.selectedRowUpdateCallback(this.selectedRow);
        }
    }
}

VSE.ListWidget2.prototype.removeSelected = function()
{
    if(this.selectedRow != "undefined")
    {
        for(var i=0; i < this.listTable.rows.length; ++i)
        {
            if(this.listTable.rows[i].id == this.selectedRow)
            {
                this.unhighlightRow(this.selectedRow);
                this.listTable.deleteRow(i);
                this.list[this.selectedRow] = null;
                this.selectedRow = "undefined";
                if(this.removeCallback != null)
                {
                    this.removeCallback();
                }
                break;
            }
        }
    }
}

function rowClickListener(rowID)
{
    var hiddenHref = $(rowID + "_SelectRow");
    if(hiddenHref != null)
    {
        //hiddenHref.click();
        document.location.href = hiddenHref.href;
    }
}

VSE.ListWidget2.prototype.SelectRow = function(rowID)
{
    var previousRow = "";
    if(this.selectedRow != "undefined")
    {
        previousRow = this.selectedRow;
        this.unhighlightRow(this.selectedRow);
    }

    this.highlightRow(rowID);
    this.selectedRow = rowID;

    // the selection change callback should only be called when the selection
    // actually changes.
    if(this.onchangeSelectionCallback != null && (previousRow != this.selectedRow))
    {
        this.onchangeSelectionCallback(this.list[this.selectedRow]);
    }
}

VSE.ListWidget2.prototype.highlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "lightsteelblue";
}

VSE.ListWidget2.prototype.unhighlightRow = function(rowID)
{
    var targetRow = $(rowID);
    targetRow.bgColor = "white";
}

VSE.ListWidget2.prototype.getSelected = function()
{
    if(this.selectedRow == "undefined")
    {
        return null;
    }
    else
    {
        return this.list[this.selectedRow];
    }
}

VSE.ListWidget2.prototype.getItem = function(rowID)
{
    return this.list[rowID];
}

VSE.ListWidget2.prototype.clearList = function()
{
    for(var i = this.listTable.rows.length-1; i > -1; i--)
    {
        this.listTable.deleteRow(i)
    }
    this.list = {};
    this.id = 0;
    this.selectedRow = "undefined";
}

function ListSelectRow(listObject, rowID)
{
    alert(listObject + ", " + rowID);    
}