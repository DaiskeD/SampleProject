// ===========================================================================
// Generic event handler for items that do not need specific handling when
// their state is changed.
// ===========================================================================
function onChange()
{
    stateChangeHandler(true, isTaskValid());
}

// ===========================================================================
// Called by orion whenever the state of the form changes (checkbox checked,
// textbox edited, etc.)
//
// We use this to deteremine whether or not the Next button should be
// enabled
// ===========================================================================
function taskStateChangeHandler( isDirty, isValid )
{
    if(isValid && isDirty)
    {
        OrionWizard.enableNavigation();
    }
    else
    {
        OrionWizard.disableNavigation();
    }
}